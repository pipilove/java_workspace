package DataForFGM;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class SplitTrainAndTest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
//		String nodeFile = "G:\\research\\personality\\StatisticsTest\\big5Subnet\\lda\\all5label\\nodes2.txt";
//		String nodeFile = "G:\\research\\personality\\StatisticsTest\\big5Subnet\\lda\\nodes.csv";
		String nodeFile = "E:\\dataSet\\cora\\cora\\data\\nodes.txt";
		ArrayList<Integer> typeList = new ArrayList<>();
		
		Scanner scanner = new Scanner(new File(nodeFile));
		
		while (scanner.hasNextLine()) {
			
			String lineString = scanner.nextLine();
			String type = lineString.split(",")[0];
			if (type.equals("+")) {
				typeList.add(0);
			}else {
				typeList.add(1);
			}
		}
		scanner.close();
		
		String head = "";
//		fw.write("@relation svd_big5 \n");
		for (int i = 0; i < 1433; i++) {
			head +="@attribute 'attribute_" + i+"' real \n";
		}
//		head += "@attribute 'Class' {0,1}\n\n";
		head += "@attribute 'Class' {0,1,2,3,4,5,6}\n\n";
		head += "@data\n";
		//
//		String filePath = "G:\\research\\personality\\StatisticsTest\\big5Subnet\\lda\\5label2\\";
//		String filePath = "G:\\research\\personality\\StatisticsTest\\big5Subnet\\lda\\";
		String filePath = "E:\\dataSet\\cora\\cora\\";
		
		String tp_fileString = filePath +"nodes.txt";
		scanner = new Scanner(new File(tp_fileString));
		
		FileWriter fw_train = new FileWriter(filePath+"train.arff");
		FileWriter fw_test = new FileWriter(filePath+"test.arff");
		fw_train.write("@relation core_"+"train \n");
		fw_train.write(head);
		fw_test.write("@relation core_"+"test \n");
		fw_test.write(head);
		
		int k=0;
		while (scanner.hasNextLine()) {
			String lineString = scanner.nextLine();
			if (typeList.get(k)==0) {
				fw_train.write(lineString+"\n");
			}else {
				fw_test.write(lineString+"\n");
			}
			k++;
		}
		
		fw_train.flush();
		fw_train.close();
		fw_test.flush();
		fw_test.close();
		
		
		
//		for (int i = 1; i <= 5; i++) {
//			String tp_fileString = filePath +i+".csv";
//			scanner = new Scanner(new File(tp_fileString));
//			
//			FileWriter fw_train = new FileWriter(filePath+i+"_train.arff");
//			FileWriter fw_test = new FileWriter(filePath+i+"_test.arff");
//			fw_train.write("@relation svd_big5_"+i+"_train \n");
//			fw_train.write(head);
//			fw_test.write("@relation svd_big5_"+i+"_test \n");
//			fw_test.write(head);
//			
//			int k=0;
//			while (scanner.hasNextLine()) {
//				String lineString = scanner.nextLine();
//				if (typeList.get(k)==0) {
//					fw_train.write(lineString+"\n");
//				}else {
//					fw_test.write(lineString+"\n");
//				}
//				k++;
//			}
//			
//			fw_train.flush();
//			fw_train.close();
//			fw_test.flush();
//			fw_test.close();
//			
//			
//		}
	}

}
