package DataForFGM;

import java.beans.FeatureDescriptor;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class OneClassWithPrior {

	
	
	
	private static void mergeNodeWithPrior() {
		// TODO Auto-generated method stub
		String file_node = "E:\\dataSet\\cora\\cora\\data\\nodes.txt";
		
		String file_distribution  = "E:\\dataSet\\cora\\cora\\distribution1.txt";
		String file_outNode = "E:\\dataSet\\cora\\cora\\Node_distribution.txt";
		
		try {
			FileWriter fw = new FileWriter(file_outNode);
			
			Scanner scanner = new Scanner(new File(file_distribution));
			
			ArrayList<String> distribution = new ArrayList<>();
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				distribution.add(lineString);
			}
			scanner.close();
			
			scanner = new Scanner(new File(file_node));
			
			int k = 0;
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tempStrings = lineString.split(",");
				
				String outString = tempStrings[0]+","+tempStrings[1];
				
				String[] tpStrings = distribution.get(k).split(" ");
				for (int i = 0; i < tpStrings.length; i++) {
					outString += ","+tpStrings[i];
				}
				
				for (int i = 2; i < tempStrings.length; i++) {
					outString += ","+ tempStrings[i];
				}
				
				fw.write(outString+"\n");
				
				
			}
			
			scanner.close();
			fw.flush();
			fw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		mergeNodeWithPrior();
		
		/*
		String nodefile = "G:\\research\\personality\\StatisticsTest\\big5Subnet\\lda\\all5label\\nodes2.txt";
		
		String outfile = "G:\\research\\personality\\StatisticsTest\\big5Subnet\\lda\\5label2\\node.txt";
		
		try {
			Scanner scanner = new Scanner(new File(nodefile));
			FileWriter fw = new FileWriter(outfile);
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				
				String[] tpStrings = lineString.split(",");
				String outString = tpStrings[0]+","+tpStrings[1];
				for (int i = 6; i < tpStrings.length; i++) {
					outString += "," + tpStrings[i]; 
				}
				
				fw.write(outString+"\n");
			}
			
			scanner.close();
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO: handle exception
		}
		*/
		
		
		
	}

}
