package weka;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;

import weka.classifiers.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Instances;


public class WekaBP {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader reader = new BufferedReader(
                new FileReader("F:\\ʵϰ�ļ�\\PAKDD\\trainingdataV2.arff"));
		 Instances data = new Instances(reader);
		 data.setClassIndex(data.numAttributes() - 1);
		BufferedReader reader1 = new BufferedReader(
                new FileReader("F:\\ʵϰ�ļ�\\PAKDD\\testDataV2.arff"));
		 Instances testData = new Instances(reader1);
		 testData.setClassIndex(testData.numAttributes() - 1);
		 MultilayerPerceptron BPmodel = (MultilayerPerceptron) LoadModel("F:\\ʵϰ�ļ�\\PAKDD\\PAKDD_BPmodel.model");
		 
		 System.out.println(" training complete!\n start evaluation!");
		 Evaluation evaltrain = new Evaluation(data);
		 evaltrain.evaluateModel(BPmodel, data);
		 System.out.println(evaltrain.toSummaryString("\nResults\n======\n", false));
		 Evaluation eval = new Evaluation(testData);
//		 eval.crossValidateModel(smo, data, 3, new Random(2));
		 
		 double[] resultlabel = eval.evaluateModel(BPmodel, testData);
		 System.out.println(" evaluation complete!\n start output!");
		 FileWriter fw = new FileWriter("F:\\ʵϰ�ļ�\\PAKDD\\BPreuslt.txt");
		 String[] resultLabel = new String[2];
		 resultLabel[0] = "female";
		 resultLabel[1] = "male";
		 // label instances
		 for (int i = 0; i < resultlabel.length; i++) {
			   int num = (int) resultlabel[i];
			   System.out.println(num);
			   fw.write(resultLabel[num]+"\n");
			 }
		 // save labeled data
		 fw.flush();
		 fw.close();
		 
		 
		
	}
	
	public static Object LoadModel(String file){
        try{
            ObjectInputStream ois=new ObjectInputStream(new FileInputStream(file));
            Object classifier=ois.readObject();
            ois.close();
            return classifier;
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }catch(ClassNotFoundException e){
            e.printStackTrace();
            return null;
        }
    }

}
