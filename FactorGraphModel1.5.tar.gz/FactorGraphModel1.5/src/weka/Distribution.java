package weka;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LibSVM;
import weka.core.Instances;

public class Distribution {

	
	private static void Model2Distribution() throws Exception {
		// TODO Auto-generated method stub
		
		
		
		BufferedReader reader = new BufferedReader(
//                new FileReader("E:\\dataSet\\cora\\cora\\train.arff"));
                new FileReader("E:\\dataSet\\cora\\cora\\train_prior.arff"));
		 Instances data = new Instances(reader);
		 data.setClassIndex(data.numAttributes() - 1);
		BufferedReader reader1 = new BufferedReader(
//                new FileReader("E:\\dataSet\\cora\\cora\\test.arff"));
                new FileReader("E:\\dataSet\\cora\\cora\\test_prior.arff"));
		 Instances data2 = new Instances(reader1);
		 data2.setClassIndex(data2.numAttributes() - 1);
		 
		 BufferedReader reader2 = new BufferedReader(
//	                new FileReader("E:\\dataSet\\cora\\cora\\data.arff"));
	                new FileReader("E:\\dataSet\\cora\\cora\\data_prior.arff"));
			 Instances data_all = new Instances(reader2);
			 data_all.setClassIndex(data_all.numAttributes() - 1);
		 
		 FileWriter fw = new FileWriter("E:\\dataSet\\cora\\cora\\distribution3.txt");
		 
		 
//		 LibSVM classifier = (LibSVM) LoadModel("E:\\dataSet\\cora\\cora\\libsvm1.model");
		 // Deserialize the classifier.
		 Classifier classifier =     (Classifier) weka.core.SerializationHelper.read("E:\\dataSet\\cora\\cora\\RandomForest10_fold_prior.model");
//		 Classifier classifier =     (Classifier) weka.core.SerializationHelper.read("E:\\dataSet\\cora\\cora\\libsvm2.model");
//		 Evaluation evaltrain = new Evaluation(data);
		 Instances  testData = data_all;
		 
		 for (int i = 0; i < testData.numInstances(); i++) {
			 // Get the true class label from the instance's own classIndex.
			 String trueClassLabel =   testData.instance(i).toString(testData.classIndex());
			 
			// Make the prediction here.
		    double predictionIndex =   classifier.classifyInstance(testData.instance(i));
		    
		    // Get the predicted class label from the predictionIndex.
	        String predictedClassLabel =     testData.classAttribute().value((int) predictionIndex);
	        
	        // Get the prediction probability distribution.
	        double[] predictionDistribution =  classifier.distributionForInstance(testData.instance(i));
	 
	        // Print out the true label, predicted label, and the distribution.
	        System.out.printf("%5d: true=%-5s, predicted=%-5s, distribution=",i, trueClassLabel, predictedClassLabel);
//	        String outString = String.format("%5d: true=%-5s, predicted=%-5s, distribution=",i, trueClassLabel, predictedClassLabel);
//	        fw.write(outString);
	        String outString = "";
	        // Loop over all the prediction labels in the distribution.
	        for (int predictionDistributionIndex = 0; predictionDistributionIndex < predictionDistribution.length;predictionDistributionIndex++)
	        {
	            // Get this distribution index's class label.
//	            String predictionDistributionIndexAsClassLabel =
//	            		testData.classAttribute().value(
//	                    predictionDistributionIndex);
//	 
	            // Get the probability.
	            double predictionProbability =
	                predictionDistribution[predictionDistributionIndex];
	 
	            System.out.printf("%6.8f ",predictionProbability );
	            
	            outString += String.format("%6.8f ",predictionProbability);
	            
	        }
	        fw.write(outString+"\n");
	        System.out.println();
			 
		}
		 
		 fw.flush();
		 fw.close();
		 
		 
		 Evaluation eval = new Evaluation(data);
		 eval.evaluateModel(classifier, data2);
		 System.out.println(eval.toSummaryString("\nResults\n======\n", false));
		 System.out.println(eval.toClassDetailsString());
		 
	}
	
	
	
	public static Object LoadModel(String file){
        try{
            ObjectInputStream ois=new ObjectInputStream(new FileInputStream(file));
            Object classifier=ois.readObject();
            ois.close();
            return classifier;
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }catch(ClassNotFoundException e){
            e.printStackTrace();
            return null;
        }
	}
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Model2Distribution();
	}

}
