package pipi.wildfire;

public class Config {
//	public int my_rank, num_procs;
	public String task;
//	public String train_file;	//notuse
//	public String test_file;
//	public String pred_file;
	
	String nodeFile;
	String edgeFile;
	
	public String dict_file;
	public String src_model_file;	
	public String dst_model_file;	//for save trained model
	
	String probability_w ;
	String train_log;
	String likelihood_log;
	
	int  seed;
	public double eps;
	
	public int max_iter;
	public int max_bp_iter;

	
	public double gradient_step;
	double max_step;
	double min_step;
	
//	public boolean eval_each_iter;	//not use
	
	public Config() {
		SetDefault();
	}
	
	void setWithRoot(String dir){
		this.nodeFile = dir+"model/data/nodes.txt";
		this.edgeFile =  dir+"model/data/edges.txt";
		
		this.dst_model_file =  dir+"model/result/model.txt";
		this.probability_w =  dir+"model/result/probanility.txt";
		this.train_log =  dir+"model/result/train_log.txt";
		this.likelihood_log =  dir+"model/result/likelihood_log.txt";
	}
	
	void setWithRootv2(String dir){
		this.nodeFile = dir+"data/nodes.txt";
		this.edgeFile =  dir+"data/edges.txt";
		
		this.dst_model_file =  dir+"result/model.txt";
		this.probability_w =  dir+"result/probanility.txt";
		this.train_log =  dir+"result/train_log.txt";
		this.likelihood_log =  dir+"result/likelihood_log.txt";
	}

	private void SetDefault() {
		max_iter = 50;
		max_bp_iter = 10;
		
		task = "-est";
//		test_file = "model/test.txt";
	    dict_file = "model/dict.txt";
//	    pred_file = "model/pred.txt";
	    
	    eps = 1e-3;
	    gradient_step = 0.1;
	    
	    dst_model_file = "model/model-final.txt";
	    
//	    eval_each_iter = true;
	    
	}
	
	boolean LoadConfig(int my_rank, int argc, String[] argv){
//		this.my_rank = my_rank;
		
		int i = 1;
	    if (argv[1].equals("-est") || argv[1].equals("-estc") || argv[1].equals("-inf"))
	    {
	        this.task = argv[1];
	        i ++;
	    }else {
			return false;
		}
	    
	    //not complete!!!
	    
	    return true;
		
	}
	
	static void ShowUsage(){
		
	}
	
	
	
	
}
