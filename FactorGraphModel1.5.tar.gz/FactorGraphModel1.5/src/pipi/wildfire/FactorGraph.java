package pipi.wildfire;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.Scanner;


public class FactorGraph {
	
	public static ArrayList<Node> nodes; 
	
	int n,m,num_label;
	
	int num_node;
	int num_feature;
	boolean converged;
	Diff diff;
	
	boolean labeled_given;
	int[] bfs_node ;
	
	//bfs nodes for each connected component
	int[][] bfs_node_cc;
	
	
	/*7
	 * InitGraph: initiate variable node first
	 * 
	 *  load node profile
	 *  n,m,num_label
	 *  id,feature
	 *  
	 *  k : the number of nodes, a round number for initiate
	 */
	void InitGraph( int num_label,int num_feature, int k){
//		this.n = n; //number of variable node
//		this.m = m; //number of factor node
		this.num_label = num_label;
		this.num_feature = num_feature;
		
		nodes = new ArrayList<>(k);
		diff = new Diff();

	}
	
	
	void GenPropagateOrder1(){
		num_node = nodes.size();
		bfs_node = new int[num_node];
		boolean[] mark  = new boolean[nodes.size()];
		
		for (int i = 0; i < nodes.size(); i++) {
			mark[i] = false;
		}
		
		int head = 0, tail = -1;
		int pos = 0;
		for (int i = 0; i < num_node; i++) {
			if (!mark[i]) {	//node not visited
				bfs_node[++tail] = i;
				mark[i] = true;
				
				while (head <= tail) {
					Node u = nodes.get(bfs_node[head++]);
					
					for(Integer neighbor_id : u.neighbor_pos.keySet()){
						if (!mark[neighbor_id]) {
							bfs_node[++tail] = neighbor_id;
							mark[neighbor_id] = true;
						}
					}
				}
			}
		}
		
		mark = null;	//release
	}

	void GenPropagateOrder(){
		String file_cc_start = "E:\\dataSet\\cora\\cora\\data\\start_leaves1.txt";
		
		
		ArrayList<Integer> cc_leaveList = new ArrayList<>();
		try {
			Scanner scanner = new Scanner(new File(file_cc_start));
			
			while (scanner.hasNextLine()) {
				String lineString =  scanner.nextLine();
				
				cc_leaveList.add(Integer.valueOf(lineString));
			}
			scanner.close();
			
			int num_cc = cc_leaveList.size();
			bfs_node_cc = new int[num_cc][];
			
			
			int sum_cc = 0;
			
			for (int i = 0; i < num_cc; i++) {
				
				int start_id = cc_leaveList.get(i);
				
				TreeMap<Integer, Integer> bfsMap = new TreeMap<>();
				HashSet<Integer> preSet = new HashSet<>();
				
				bfsMap.put(0, start_id);
				
				HashMap<Integer, Integer> v_nbMap = nodes.get(start_id).neighbor_pos;
//				ArrayList<Integer> v_nbList = vertexs[start_id].nbList;
				for(Entry<Integer, Integer> entry: v_nbMap.entrySet()){
					int nb_id = entry.getKey();
				
					bfsMap.put(bfsMap.size(), nb_id);
					
					preSet.add(nb_id);
				} 
				
				while(preSet.size()>0){
					
					HashSet<Integer> innerSet = new HashSet<>();
					
					for (Integer nb_id : preSet) {
						v_nbMap = nodes.get(nb_id).neighbor_pos;
						for(Entry<Integer, Integer> entry: v_nbMap.entrySet()){
							int v_nb_id = entry.getKey();
							if (!bfsMap.containsValue(v_nb_id)) {
								innerSet.add(v_nb_id);
							}
						} 
					}
					
					for (Integer value : innerSet) {
		    			
		    				bfsMap.put(bfsMap.size(), value);
						
					}
		    		
		    		
		    		preSet.clear();
		    		preSet.addAll(innerSet);
		    		innerSet.clear();
				}
				
				bfs_node_cc[i] = new int[bfsMap.size()];
				int k = 0;
				for(Entry<Integer, Integer> entry: bfsMap.entrySet()){
					bfs_node_cc[i][k++] = entry.getValue();
//					System.out.print(entry.getValue()+", ");
				}
				
//				System.out.print("\n");
				sum_cc += k;
			}
			
			System.err.println("total #noddes: " + sum_cc);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	void ClearDataForSumProduct(){
		
		
//		System.out.println("in here");
		for (int i = 0; i < n; i++) {
			Util.DoubleArrFill(((VariableNode)nodes.get(i)).state_factor,1/(double)num_label);					
		}
		
		for (int i = 0; i < num_node; i++) {
			Node currentNode = nodes.get(i);
			for (int j = 0; j < currentNode.belief.size(); j++) {
				Util.DoubleArrFill(currentNode.belief.get(j), 1/(double)num_label);
//				double[] dst_belief = currentNode.belief.get(j);
//				double[] dst_belief_old = currentNode.belief_old.get(j);
//				for (int k = 0; k < dst_belief.length; k++) {
//					dst_belief[k] = 1/(double)num_label;
////					System.out.println(dst_belief[k] );
//					dst_belief_old[k] = 0;
//				}
//				Util.DoubleArrFill(currentNode.belief.get(j), 0);
			}
		}
	}

	void SetVariableLabel(int u, int y) { ((VariableNode)nodes.get(u)).y = y; }
	void SetVariableStateFactor(int u, int y, double v){
		((VariableNode)nodes.get(u)).state_factor[y] = v;
	}
	
	void BeliefPropagation1(int max_iter){
		int start, end, dir;
		
		converged = false;
		for (int iter = 0; iter < max_iter; iter++) {
			diff.diff_max = 0.0;
			
			if (iter%2 == 0) {
				start = num_node -1; end = -1;  dir = -1;
			}else {
				start = 0; end = num_node;  dir = 1;
			}
			
			for (int p = start ; p!=end; p += dir) {
				nodes.get(bfs_node[p]).BeliefPropagation(diff, this.labeled_given);
			}
			
			if (diff.diff_max < 1e-6) {
				System.out.println("converged : "+ iter);
				break;
			}
			
			//print belief
//			 try {
//				FileWriter fw = new FileWriter("model/temp/belief.txt");
//				
//				 for (int i = 0; i < num_node; i++) {
//						Node node = nodes.get(i);
//						String beliefString = "";
//						for (int j = 0; j < node.belief.size(); j++) {
//							for (int j2 = 0; j2 < num_label; j2++) {
//								beliefString +=node.belief.get(j)[j2]+" ";
//							}
//							beliefString +=",";
//						}
//						
//						fw.write(beliefString+"\n");
//				}
//				 
//				 fw.flush();
//				 fw.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			 
//			System.exit(0);

		}
	}
	
	void MaxSumPropagation1(int max_iter){
		int start, end, dir;
		
		converged = false;
		for (int iter = 0; iter < max_iter; iter++) {
			diff.diff_max = 0.0;
			
			if (iter%2 == 0) {
				start = num_node -1; end = -1;  dir = -1;
			}else {
				start = 0; end = num_node;  dir = 1;
			}
			
			for (int p = start ; p!=end; p += dir) {
				nodes.get(bfs_node[p]).MaxSumPropagation(diff, this.labeled_given);
			}
			
			if (diff.diff_max < 1e-6) {
				break;
			}
		}
	}
	
	
	void BeliefPropagation2(int max_iter){
		int start, end, dir;
		
		int converged_count = 0;
		
		for (int i = 0; i < bfs_node_cc.length; i++) {
			
			
			int cc_size = bfs_node_cc[i].length;
			for (int iter = 0; iter < max_iter/2; iter++) {
				
				
//				if (iter%2 == 0) {
//					start = cc_size -1; end = -1;  dir = -1;
//				}else {
//					start = 0; end = cc_size;  dir = 1;
//				}
				//for leave to root
				Diff aDiff = new Diff();
				aDiff.diff_max = 0.0;
				start = cc_size -1; end = -1;  dir = -1;
				for (int p = start ; p!=end; p += dir) {
					nodes.get(bfs_node_cc[i][p]).BeliefPropagation(aDiff, this.labeled_given);
				}
				
//				if (aDiff.diff_max < 1e-8) {
//					System.out.println("converged : "+ iter);
//				}
//				
				//from root to leave
				Diff bDiff = new Diff();
				bDiff.diff_max = 0.0;
				start = 0; end = cc_size;  dir = 1;
				for (int p = start ; p!=end; p += dir) {
					nodes.get(bfs_node_cc[i][p]).BeliefPropagation(bDiff, this.labeled_given);
				}
				if ((aDiff.diff_max < 1e-8) && (bDiff.diff_max < 1e-8) ) {
					System.err.println("cc converged! " + iter);
					converged_count ++;
					break;
				}
			}
		}
//		if (converged_count == bfs_node_cc.length) {
//			System.err.println("all converged!");
//		}else {
//			System.err.println("converged count: " + converged_count);
//		}
		
	}
	
	void MaxSumPropagation2(int max_iter){
		int start, end, dir;
		
		int converged_count = 0;
		
		for (int i = 0; i < bfs_node_cc.length; i++) {
			
			
			int cc_size = bfs_node_cc[i].length;
			for (int iter = 0; iter < max_iter/2; iter++) {
				
				
//				if (iter%2 == 0) {
//					start = cc_size -1; end = -1;  dir = -1;
//				}else {
//					start = 0; end = cc_size;  dir = 1;
//				}
				//for leave to root
				Diff aDiff = new Diff();
				aDiff.diff_max = 0.0;
				start = cc_size -1; end = -1;  dir = -1;
				for (int p = start ; p!=end; p += dir) {
					nodes.get(bfs_node_cc[i][p]).MaxSumPropagation(aDiff, this.labeled_given);
				}
				
//				if (aDiff.diff_max < 1e-8) {
//					System.out.println("converged : "+ iter);
//				}
				
//				from root to leave
				Diff bDiff = new Diff();
				bDiff.diff_max = 0.0;
				start = 0; end = cc_size;  dir = 1;
				for (int p = start ; p!=end; p += dir) {
					nodes.get(bfs_node_cc[i][p]).MaxSumPropagation(bDiff, this.labeled_given);
				}
				if ((aDiff.diff_max < 1e-8) && (bDiff.diff_max < 1e-8) ) {
					System.err.println("cc converged!" + iter);
					converged_count ++;
					break;
				}
			}
		}
	}

	
	
	void BeliefPropagation(int max_iter){
		int start, end, dir;
		
		int converged_count = 0;
		
		for (int i = 0; i < bfs_node_cc.length; i++) {
			
			
			int cc_size = bfs_node_cc[i].length;
			for (int iter = 0; iter < max_iter; iter++) {
				
				
				if (iter%2 == 0) {
					start = cc_size -1; end = -1;  dir = -1;
				}else {
					start = 0; end = cc_size;  dir = 1;
				}
				//for leave to root
				Diff aDiff = new Diff();
				aDiff.diff_max = 0.0;
//				start = cc_size -1; end = -1;  dir = -1;
				for (int p = start ; p!=end; p += dir) {
					nodes.get(bfs_node_cc[i][p]).BeliefPropagation(aDiff, this.labeled_given);
				}
				
				if (aDiff.diff_max < 1e-8) {
					System.out.println("converged : "+ iter);
				}
//				
//				//from root to leave
//				Diff bDiff = new Diff();
//				bDiff.diff_max = 0.0;
//				start = 0; end = cc_size;  dir = 1;
//				for (int p = start ; p!=end; p += dir) {
//					nodes.get(bfs_node_cc[i][p]).BeliefPropagation(bDiff, this.labeled_given);
//				}
//				if ((aDiff.diff_max < 1e-8) && (bDiff.diff_max < 1e-8) ) {
//					System.err.println("cc converged! " + iter);
//					converged_count ++;
//					break;
//				}
			}
		}
//		if (converged_count == bfs_node_cc.length) {
//			System.err.println("all converged!");
//		}else {
//			System.err.println("converged count: " + converged_count);
//		}
		
	}
	
	void MaxSumPropagation(int max_iter){
		int start, end, dir;
		
		int converged_count = 0;
		
		for (int i = 0; i < bfs_node_cc.length; i++) {
			
			
			int cc_size = bfs_node_cc[i].length;
			for (int iter = 0; iter < max_iter; iter++) {
				
				
				if (iter%2 == 0) {
					start = cc_size -1; end = -1;  dir = -1;
				}else {
					start = 0; end = cc_size;  dir = 1;
				}
				//for leave to root
				Diff aDiff = new Diff();
				aDiff.diff_max = 0.0;
//				start = cc_size -1; end = -1;  dir = -1;
				for (int p = start ; p!=end; p += dir) {
					nodes.get(bfs_node_cc[i][p]).MaxSumPropagation(aDiff, this.labeled_given);
				}
				
				if (aDiff.diff_max < 1e-8) {
					System.out.println("converged : "+ iter);
				}
				
//				from root to leave
//				Diff bDiff = new Diff();
//				bDiff.diff_max = 0.0;
//				start = 0; end = cc_size;  dir = 1;
//				for (int p = start ; p!=end; p += dir) {
//					nodes.get(bfs_node_cc[i][p]).MaxSumPropagation(bDiff, this.labeled_given);
//				}
//				if ((aDiff.diff_max < 1e-8) && (bDiff.diff_max < 1e-8) ) {
//					System.err.println("cc converged!" + iter);
//					converged_count ++;
//					break;
//				}
			}
		}
	}

	
	
	void CalculateMarginal(){
		
		// n variable nodes for y
		for (int i = 0; i < n; i++) {
			double sum_py = 0.0;
			
			//debug
			String debugString = "debug-margin: ";
			
			VariableNode vNode = (VariableNode) nodes.get(i);
			for (int y = 0; y < num_label; y++) {
				
				vNode.marginal[y] = vNode.state_factor[y];
				
				debugString +="State_factor: "+ vNode.marginal[y] ;
				
				for (int t = 0; t < vNode.belief.size(); t++) {
					vNode.marginal[y] *= vNode.belief.get(t)[y];
					
					debugString +="\n *belief" + vNode.belief.get(t)[y]+"->"+vNode.marginal[y];
				}
				debugString +="\n computed:"+ vNode.marginal[y] ;
				sum_py += vNode.marginal[y];
			}
			
			for (int y = 0; y <	num_label; y++) {
				vNode.marginal[y] /= sum_py;
				if (Double.isNaN(vNode.marginal[y])) {
					debugString +="\n"+"sum_py:"+sum_py;
					System.err.println(debugString);
					System.exit(0);
				}
			}
		}
		
		//m factor nodes
		for (int i = n; i < num_node; i++) {
			
			double sump = 0.0;
			
			FactorNode fNode = (FactorNode) nodes.get(i);
			if (fNode.belief.size()==2) {
				for (int a = 0; a < num_label; a++) {
					for (int b = 0; b < num_label; b++) {
						fNode.marginal[a][b] = fNode.belief.get(0)[a] * 
								fNode.belief.get(1)[b]*
								fNode.func.GetValue(a, b);
						sump += fNode.marginal[a][b];
								
					}
				}
				
				for (int a = 0; a < num_label; a++) {
					for (int b = 0; b < num_label; b++) {
						fNode.marginal[a][b] /= sump;								
					}
				}
			}
			//need marginal3d
			if (fNode.belief.size()==3) {
				
			}
			//not for now, need marginal2d
			if (fNode.belief.size() > 3) {
				
			}
		}
	}

	
	
	
}
