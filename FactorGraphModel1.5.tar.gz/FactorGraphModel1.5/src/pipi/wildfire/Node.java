package pipi.wildfire;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;



public class Node {

	int             id;
    int             num_label;
//    ArrayList<Integer> neighbor; //
//    ArrayList<Double[]> belief;
    ArrayList<double[]> belief;	//belief:Double[](num_label)
    
    ArrayList<double[]> belief_old;	//belief:Double[](num_label)
    HashMap<Integer, Integer> neighbor_pos;  //node id  ->  index in the belief 
    double[] msg;
    
    double residual;
    
    public Node() {
		// TODO Auto-generated constructor stub
    	belief = new ArrayList<double[]>();
    	belief_old = new ArrayList<double[]>();
    	neighbor_pos = new HashMap<>();     	
	}
    
    void Init(int num_label){}
    void BasicInit(int num_label){
    	this.num_label = num_label;
    	msg = new double[num_label];
    }
    
    void NormalizeMessage(){
    	double s = 0;
    	
    	for (int i = 0; i < num_label; i++) {
			if (Double.isInfinite(msg[i])) {
				msg[i] = 1;
			}
			s += msg[i];			
		}
		
//		for (int i = 0; i < num_label; i++) {
//			msg[i] /= s;			
//		}
//		
		if (s==0||Double.isNaN(s)) {
			for (int i = 0; i < num_label; i++) {
				msg[i] = 1/(double) num_label;			
			}
		}else {
			for (int i = 0; i < num_label; i++) {
				msg[i] /= s;			
			}
		}	
		
    }
    
    void AddBeighbor(int id){
//    	neighbor.add(id);
    	neighbor_pos.put(id, neighbor_pos.size()); 
    	belief.add(new double[num_label]);
    	belief_old.add(new double[num_label]);
    }
    
    void BeliefPropagation(Diff diff, boolean labeled_given){}
    
    void MaxSumPropagation(Diff diff, boolean labeled_given){}
    
    void GetMessageFrom(int u, double[] msgvec, Diff diff)
    {
    	
    	 int p = neighbor_pos.get(u);
         double[] dst_belief = belief.get(p);
         double[] dst_belief_old = belief_old.get(p);
         
       
         int zero_count = 0;
//         StringBuffer debugBuffer = new StringBuffer();
         for (int y = 0; y < num_label; y ++)
         {
             if (Math.abs(dst_belief[y] - msgvec[y]) > diff.diff_max)
             	diff.diff_max = Math.abs(dst_belief[y] - msgvec[y]);
             
             dst_belief_old[y] = dst_belief[y];
             dst_belief[y] = msgvec[y];
            
             if (msgvec[y] == 0) {
				zero_count++;
			}
             
//            debugBuffer.append(msgvec[y]+" ");
          //debug
            if (Double.isNaN(msgvec[y])) {
				System.err.println("msg NAN: from:"+u+" label "+y+" "+id+" "+ neighbor_pos.size());
				System.exit(0);
			}
        }
         
         if (zero_count == num_label) {
			System.err.println("msg all zero!");
		}
//         System.out.println("msg debug: "+ debugBuffer.toString());
    }
    
    
    void skip_propadation(int from_id) {
		// TODO Auto-generated method stub
    	
    	
    	int nb_id = neighbor_pos.get(from_id);
    	double[] dst_belief = belief.get(nb_id);
    	double[] dst_belief_old = belief_old.get(nb_id);
			for (int y = 0; y < num_label; y++) {
				dst_belief_old[y]  =  dst_belief[y];
				
			}
		
	}
    
    
    void updateResidual(){ 	
    	
    	residual = 0;
    	for (int i = 0; i < belief.size(); i++) {
    		double[] dst_belief = belief.get(i);
    	    double[] dst_belief_old = belief_old.get(i);
			for (int y = 0; y < num_label; y++) {
				double diff = Math.abs(dst_belief[y] - dst_belief_old[y]);
				if (diff > residual) {
					residual = diff;
				}
			}
		}
    	
    }
}

class VariableNode extends Node{
	
	int y;
	int label_type;  //1 for known, 0 for unknown
	
	double[] state_factor;
	double[] marginal;
	double[] feature;
	
	public VariableNode() {
		
	}
	
	void Init(int num_label){
		BasicInit(num_label);
		state_factor = new double[num_label];
		marginal = new double[num_label];
	}
	
	void BeliefPropagation(Diff diff, boolean labeled_given){
		//the add operation is complete, we can free the extra space for ArrayList
		belief.trimToSize();
		
		updateResidual();
//		System.out.println("residual: "+ residual);
		if (residual > 1e-8) {
		
		double[] product = new double[num_label];
		for (int y = 0; y < num_label; y++) {
			product[y] = state_factor[y];
		}
		
		for(Entry<Integer, Integer> entry: neighbor_pos.entrySet()){
			int nodeid = entry.getKey();
			int pos = entry.getKey();
			
			FactorNode f = (FactorNode) FactorGraph.nodes.get(nodeid);
			
			
			for(Entry<Integer, Integer> entry2: neighbor_pos.entrySet()){
				int fnodeid = entry2.getKey();
				int fpos = entry2.getValue();
				if (fnodeid != nodeid) {
					for (int y = 0; y < num_label; y++) {
						product[y] *= belief.get(fpos)[y];
						if (Double.isNaN(belief.get(fpos)[y])) {
							System.err.println("NAN: varible");
						}
					}
				}
			}
			
			for (int i = 0; i < num_label; i++) {
				msg[i] = product[i];
			}
			
			
			
			
//			for (int y = 0; y < num_label; y++) {
//				product = state_factor[y];
//				for(Entry<Integer, Integer> entry2: neighbor_pos.entrySet()){
//					int fnodeid = entry2.getKey();
//					int fpos = entry2.getValue();
//					if (fnodeid != nodeid) {
//						product *= belief.get(fpos)[y];
//					}
//				}
//				msg[y] = product;
//			}
			
			NormalizeMessage();
			f.GetMessageFrom(id, msg, diff);
		}
		
		}else {
			
			for(Entry<Integer, Integer> entry: neighbor_pos.entrySet()){
				int nodeid = entry.getKey();
				Node nbNode = FactorGraph.nodes.get(nodeid);
				nbNode.skip_propadation(id);
			}
			
			
		}
		
	}
    
    void MaxSumPropagation(Diff diff, boolean labeled_given){
//    	belief.trimToSize();
    	updateResidual();
		if (residual > 1e-8) {
    	
		double[] product = new double[num_label];
		for (int y = 0; y < num_label; y++) {
			product[y] = state_factor[y];
		}
		
		for(Entry<Integer, Integer> entry: neighbor_pos.entrySet()){
			int nodeid = entry.getKey();
			int pos = entry.getKey();
			
			FactorNode f = (FactorNode) FactorGraph.nodes.get(nodeid);
			
			
			for(Entry<Integer, Integer> entry2: neighbor_pos.entrySet()){
				int fnodeid = entry2.getKey();
				int fpos = entry2.getValue();
				if (fnodeid != nodeid) {
					for (int y = 0; y < num_label; y++) {
						product[y] *= belief.get(fpos)[y];
					}
				}
			}
			
			for (int i = 0; i < num_label; i++) {
				msg[i] = product[i];
			}
			
			
			
			
//			for (int y = 0; y < num_label; y++) {
//				product = state_factor[y];
//				for(Entry<Integer, Integer> entry2: neighbor_pos.entrySet()){
//					int fnodeid = entry2.getKey();
//					int fpos = entry2.getValue();
//					if (fnodeid != nodeid) {
//						product *= belief.get(fpos)[y];
//					}
//				}
//				msg[y] = product;
//			}
			
			NormalizeMessage();
			f.GetMessageFrom(id, msg, diff);
		}
		}else {
			
			for(Entry<Integer, Integer> entry: neighbor_pos.entrySet()){
				int nodeid = entry.getKey();
				Node nbNode = FactorGraph.nodes.get(nodeid);
				nbNode.skip_propadation(id);
			}
			
			
		}
    }

	
}

class FactorNode extends Node{
	
	FactorFunction func;
	int func_type;
	
	double[][] marginal;
	
	//later can add marginal3d  or else
	
	void Init(int num_label){
		BasicInit(num_label);
		
		marginal = new double[num_label][num_label];
		
	}
	
	void BeliefPropagation(Diff diff, boolean labeled_given){
		belief.trimToSize();
		
		
		updateResidual();
		
		if (residual >1e-8) {
			
		
		//only for neighbor num of 2 and 3
		
		Integer[] neigbbors = neighbor_pos.keySet().toArray(new Integer[neighbor_pos.size()]);
		
		if (neigbbors.length ==2) {
			for (int i = 0; i < 2; i++) {
				//if (labeled_given && ((VariableNode*)neighbor[i])->label_type == Enum::KNOWN_LABEL)
				
				VariableNode vNode = (VariableNode) FactorGraph.nodes.get(neigbbors[i]);
				if (labeled_given && ( vNode.label_type==1)) {
					for (int y = 0; y < num_label; y++) {
						msg[y] = 0;
					}
					msg[vNode.y] = 1.0;
				}else {
					for (int y = 0; y < num_label; y++) {
						double s = 0;
						for (int y1 = 0; y1 < num_label; y1++) {
							int pos = neighbor_pos.get(neigbbors[1-i]);
							double ts = func.GetValue(y, y1) * belief.get(pos)[y1];
//							s += (Double.isNaN(ts))?0:ts;
							s += ts;
							if (Double.isNaN(ts)) {
								System.err.println("NAN: factor" + "getValue: "+func.GetValue(y, y1)+" belief:"+belief.get(pos)[y1]);
							}
						}
						msg[y] = s;
					}
					NormalizeMessage();
				}
				
				vNode.GetMessageFrom(id, msg, diff);
				
			}
		}else {			
			System.out.println("goes here");
			for (int i = 0; i < 3; i++) {
				VariableNode vNode = (VariableNode) FactorGraph.nodes.get(neigbbors[i]);
				if (labeled_given && vNode.label_type==1) {
					for (int y = 0; y < num_label; y++) {
						msg[y] = 0;
					}
					msg[vNode.y] = 1.0;
				}else {
					for (int y  = 0; y  < num_label; y ++) {
						double s = 0;
						for (int y1 = 0; y1 < num_label; y1++) {
							for (int y2 = 0; y2 < num_label; y2++) {
								double b = belief.get((i==2)?0:(i+1))[y1]*belief.get((i==0)?2:(i-1))[y2];
								double g = (i ==0)?func.GetValue(y, y1, y2) :((i == 1) ? func.GetValue(y2, y, y1) : func.GetValue(y1, y2, y)); 
								
								double ts = g*b;
								s += (Double.isNaN(ts))?0:ts;
								s += ts;
							}
						}
						msg[y] = s;
					}
					NormalizeMessage();
					
				}
				
				vNode.GetMessageFrom(id, msg, diff);
			}
		}
		}else {
			for(Entry<Integer, Integer> entry: neighbor_pos.entrySet()){
				int nodeid = entry.getKey();
				Node nbNode = FactorGraph.nodes.get(nodeid);
				nbNode.skip_propadation(id);
			}
		}
	}
	
	void MaxSumPropagation(Diff diff, boolean labeled_given){
		belief.trimToSize();
		
		updateResidual();
		
		if (residual > 1e-8) {
			
		
			//only for neighbor num of 2 and 3
			
			Integer[] neigbbors = neighbor_pos.keySet().toArray(new Integer[neighbor_pos.size()]);
			
			if (neigbbors.length ==2) {
				for (int i = 0; i < 2; i++) {
					//if (labeled_given && ((VariableNode*)neighbor[i])->label_type == Enum::KNOWN_LABEL)
					VariableNode vNode = (VariableNode) FactorGraph.nodes.get(neigbbors[i]);
					if (labeled_given && ( vNode.label_type==1)) {
						for (int y = 0; y < num_label; y++) {
							msg[y] = 0;
						}
						msg[vNode.y] = 1.0;
					}else {
						for (int y = 0; y < num_label; y++) {
							double s = -1e200;
							for (int y1 = 0; y1 < neigbbors.length; y1++) {
								int pos = neighbor_pos.get(neigbbors[1-i]);
								double t = func.GetValue(y, y1) * belief.get(pos)[y1];
								if (t > s) {
									s = t;
								}
							}
							msg[y] = s;
						}
						NormalizeMessage();
					}
					
					vNode.GetMessageFrom(id, msg, diff);
					
				}
			}else {			
				for (int i = 0; i < 3; i++) {
					VariableNode vNode = (VariableNode) FactorGraph.nodes.get(neigbbors[i]);
					if (labeled_given && vNode.label_type==1) {
						for (int y = 0; y < num_label; y++) {
							msg[y] = 0;
						}
						msg[vNode.y] = 1.0;
					}else {
						for (int y  = 0; y  < num_label; y ++) {
							double s = -1e200;
							for (int y1 = 0; y1 < num_label; y1++) {
								for (int y2 = 0; y2 < num_label; y2++) {
									double b = belief.get((i==2)?0:(i+1))[y1]*belief.get((i==0)?2:(i-1))[y2];
									double g = (i ==0)?func.GetValue(y, y1, y2) :((i == 1) ? func.GetValue(y2, y, y1) : func.GetValue(y1, y2, y)); 
									double t= g*b;
									if (t > s) {
										s = t;
									}
								}
							}
							msg[y] = s;
						}
						NormalizeMessage();
						
					}
					
					vNode.GetMessageFrom(id, msg, diff);
				}
			}
		}else {
			for(Entry<Integer, Integer> entry: neighbor_pos.entrySet()){
				int nodeid = entry.getKey();
				Node nbNode = FactorGraph.nodes.get(nodeid);
				nbNode.skip_propadation(id);
			}
		}
		
	}
		
	
	
	
}
