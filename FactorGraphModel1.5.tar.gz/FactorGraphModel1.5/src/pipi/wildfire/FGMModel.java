package pipi.wildfire;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;





public class FGMModel {

	Config conf;
	
	
//	int         num_sample;
//    int         num_label_id;
    int         num_attrib;
    int         num_edge_type;
//	int         num_triangle_type;
    int       	num_label;
//    int 		max_iter;
   
    
    
    int num_feature;
    double[]      lambda;
    FactorGraph factor_graph;
    
    
    int             num_attrib_parameter;
    int             num_edge_feature_each_type;
//    int             num_chain_feature;
//	int[]			num_triangle_feature;
//    int[]           num_group_feature;
    Map<Integer, Integer>   edge_feature_offset;
    
    EdgeFactorFunction[] edge_func_list;
    
    void Init(int num_label, int num_edge_type, int num_attrib,int k,Config config){
    	
    	this.num_label = num_label;
    	this.num_attrib = num_attrib;
    	this.num_edge_type = num_edge_type;
    	this.conf = config;
    	
    	factor_graph = new FactorGraph();    
    	factor_graph.InitGraph( num_label, num_attrib, k);  //void InitGraph( int num_label,int num_feature, int k)
    	
    	
    }    
    
    void genFeature(){
    	num_attrib_parameter = num_attrib*num_label;
    	num_edge_feature_each_type = 0;
    	
    	edge_feature_offset = new HashMap<Integer, Integer>();
    	int offset = 0;
    	for (int y1 = 0; y1 < num_label; y1++) {
			for (int y2 = y1; y2 < num_label; y2++) {
				edge_feature_offset.put(y1*num_label + y2, offset);
				edge_feature_offset.put(y2*num_label + y1, offset);
				offset ++;
				
			}
		}
    	
    	num_edge_feature_each_type = offset;
    	num_feature = num_attrib_parameter + num_edge_feature_each_type * num_edge_type;
    	
    	lambda = new double[num_feature];
    	//bebug
    	System.out.println("#lambda:"+ lambda.length);
    	
    	
    	Random rand=  new Random(conf.seed);
    	for (int i = 0; i < num_attrib_parameter; i++) {
//			lambda[i] = rand.nextDouble() - 0.5;
//			lambda[i] = 1/(double) num_attrib_parameter;
			lambda[i] = 1/(double) num_attrib_parameter + rand.nextDouble()/10;
//			System.err.println(lambda[i]);
		}
    	
    	for (int i = num_attrib_parameter; i < num_feature; i++) {
			lambda[i] = 1/(double) num_edge_feature_each_type +  rand.nextDouble()/10;
//			lambda[i] = 1/(double) num_edge_feature_each_type;
//    		lambda[i] = rand.nextDouble() - 0.5;
		}
//    	System.out.println("Lambda:");
//		String logString = "";
//		
//		for (int i = 0; i < num_feature; i++) {
////			logString += lambda[i]+" ";
//			System.out.println(lambda[i]);
//		}
//		System.out.println(logString);
//    	
    	
    	edge_func_list = new EdgeFactorFunction[num_edge_type];
    	
    	for (int i = 0; i < num_edge_type; i++) {
    		//set the beginning of each feature, transfer lambda as a refer for space limitation 
    		int bias = num_attrib_parameter + num_edge_feature_each_type*i;
			edge_func_list[i] = new EdgeFactorFunction(num_label, lambda, edge_feature_offset,bias);
		}	
    	
    	factor_graph.num_feature = num_feature;
    	
//    	log_debug();
    }
    
    
    
    void loadData(String nodeFile, String edgeFile){
		
		try {
			Scanner scanner = new Scanner(new File(nodeFile));
			
			String lineString = "";
			String[] tempStrings = null;
			int n = 0;
			while (scanner.hasNextLine()) {
				n++;
				
				lineString = scanner.nextLine();
				
				VariableNode curt_node = new VariableNode();
				
				curt_node.Init(num_label);
				
				tempStrings = lineString.split(",");
				
				int label_type = 1;
				if (tempStrings[0].equals("?")) {
					label_type = 0;
				}else if (tempStrings[0].equals("+") ) {
					label_type = 1;
				}else {
					System.err.println("wrong format");
					System.err.println(tempStrings[0]);
					System.exit(0);
				}
				
				int label = Integer.valueOf(tempStrings[1]);
				
//				int featureSize = tempStrings.length-2;
				
				curt_node.feature = new double[num_attrib];
				for (int i = 2, k = tempStrings.length; i < k; i++) {
					curt_node.feature[i-2] = Double.valueOf(tempStrings[i]);
				}
				
				int id = FactorGraph.nodes.size();
				curt_node.id = id;
				curt_node.label_type = label_type;
				curt_node.y = label;
				
				FactorGraph.nodes.add(curt_node);				
			}
			
			scanner.close();
			
			factor_graph.n = n;   //number of variable node
			
			
			scanner = new Scanner(new File(edgeFile));
			
			n = 0;
			while (scanner.hasNextLine()) {
				lineString = scanner.nextLine();
				tempStrings = lineString.split(",");
				n++;
				
				if (tempStrings[0].equals("#edge") ) {//edge	id1,id2,edge_type
					int a = Integer.valueOf(tempStrings[1]);
					int b = Integer.valueOf(tempStrings[2]);
					int edge_type = Integer.valueOf(tempStrings[3]);
					
					FactorNode factorNode = new FactorNode();
					factorNode.Init(num_label);
					factorNode.id = FactorGraph.nodes.size();
					factorNode.func = edge_func_list[edge_type];	
					factorNode.func_type = edge_type;
					
					factorNode.AddBeighbor(a);
					factorNode.AddBeighbor(b);
					FactorGraph.nodes.get(a).AddBeighbor(factorNode.id);
					FactorGraph.nodes.get(b).AddBeighbor(factorNode.id);
					
					
					FactorGraph.nodes.add(factorNode);
						
				}
			}
			scanner.close();
			
			FactorGraph.nodes.trimToSize();
			factor_graph.m = n;		//number of function node
			
			factor_graph.num_node = FactorGraph.nodes.size();
			
			printRealLabel();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    
    void train(){
    	//init train
    	genFeature();
    	loadData(conf.nodeFile, conf.edgeFile);		//change to config type
    	factor_graph.GenPropagateOrder();
    	
    	//start train
    	double[] gradient = new double[num_feature];
    	double[] G = new double[num_feature];
    	
    	for (int i = 0; i < num_feature; i++) {
    		G[i] = Math.abs(lambda[i]);
		}
    	
    	double f; // log-likelihood
    	
    	double eta = conf.gradient_step;
    	double eps = 1e-8;
    	
    	double old_f = 0.0;
    	
    	int num_iter;
    	double step = conf.gradient_step;
    	try {
			FileWriter flog=  new FileWriter(conf.likelihood_log);
			num_iter = 0;
			boolean saveResult = false;
			boolean flag = false;
			
			int sameStep = 0;
			while(num_iter < conf.max_iter){
				num_iter ++;
				if (num_iter%10==0) {
					saveResult = true;
				}else {
					saveResult = false;
				}
				f = CalcGradient(gradient,saveResult,num_iter);
				
				
//				for (int i = 0; i < gradient.length; i++) {
//					if (Double.isNaN(gradient[i])) {
//						System.err.println("NAN: gradient "+ i);
//					}
//				}
				System.out.printf("[Iter %4d] log-likelihood : %.8f\n", num_iter, f);
				String fString = String.format("[Iter %4d] log-likelihood : %.8f\n", num_iter, f);
				flog.write(fString);
				
				if (Math.abs(old_f - f) < conf.eps) {
					sameStep ++;
					if (sameStep==10) {
						break;
					}
				
					
				}
//				if (computeNorm(lambda, old_lambda)<conf.eps && num_iter>10) {
//					break;
//				}
		        old_f = f;
			     
		        
//		        f *=-1;
		     // Normalize Graident
	            double g_norm = 0.0;
	            for (int i = 0; i < num_feature; i++)
	                g_norm += gradient[i] * gradient[i];
	            g_norm = Math.sqrt(g_norm);
	            
	            if (g_norm > 1e-8)
	            {
	                for (int i = 0; i < num_feature; i++)
	                    gradient[i] /= g_norm;
	            }
	            
//	            if (flag) {
//					conf.gradient_step *= 1.5;
//				}else {
//					conf.gradient_step *= 0.9;
//				}
//	            if (num_iter==100) {
//					conf.gradient_step /=2;
//				}
	            if (step> conf.max_step) {
					step = conf.max_step;
				}else if (step < conf.min_step) {
					step = conf.min_step;
				}
	            
	            for (int i = 0; i < num_feature; i++) {
					lambda[i] += eta/Math.sqrt(G[i] + eps) * gradient[i];
					
					G[i] = Math.sqrt(Math.pow(G[i], 2) + Math.pow(lambda[i], 2));
				}
	            
	            
	            
	            
	            
			}
			
			
			
			
			flog.flush();
			flog.close();
			
			saveResult( num_iter);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }
    
    
    void train1(){
    	//init train
    	genFeature();
    	loadData(conf.nodeFile, conf.edgeFile);		//change to config type
    	factor_graph.GenPropagateOrder();
    	
    	//start train
    	double[] gradient = new double[num_feature];
    	double[] old_lambda = new double[num_feature];
    	
    	for (int i = 0; i < num_feature; i++) {
			old_lambda[i] = lambda[i];
		}
    	
    	double f; // log-likelihood
    	
    	double old_f = 0.0;
//    	double eps = 1e-6;
    	int num_iter;
    	double step = conf.gradient_step;
    	try {
			FileWriter flog=  new FileWriter(conf.likelihood_log);
			num_iter = 0;
			boolean saveResult = false;
			boolean flag = false;
			while(num_iter < conf.max_iter){
				num_iter ++;
				if (num_iter%10==0) {
					saveResult = true;
				}else {
					saveResult = false;
				}
				f = CalcGradient(gradient,saveResult,num_iter);
				
				
//				for (int i = 0; i < gradient.length; i++) {
//					if (Double.isNaN(gradient[i])) {
//						System.err.println("NAN: gradient "+ i);
//					}
//				}
				System.out.printf("[Iter %4d] log-likelihood : %.8f\n", num_iter, f);
				String fString = String.format("[Iter %4d] log-likelihood : %.8f\n", num_iter, f);
				flog.write(fString);
				
//				if (Math.abs(old_f - f) < conf.eps) break;
				if (computeNorm(lambda, old_lambda)<conf.eps && num_iter>10) {
					break;
				}
		        old_f = f;
			     
		        
//		        f *=-1;
		     // Normalize Graident
	            double g_norm = 0.0;
	            for (int i = 0; i < num_feature; i++)
	                g_norm += gradient[i] * gradient[i];
	            g_norm = Math.sqrt(g_norm);
	            
	            if (g_norm > 1e-8)
	            {
	                for (int i = 0; i < num_feature; i++)
	                    gradient[i] /= g_norm;
	            }
	            
//	            if (flag) {
//					conf.gradient_step *= 1.5;
//				}else {
//					conf.gradient_step *= 0.9;
//				}
//	            if (num_iter==100) {
//					conf.gradient_step /=2;
//				}
	            if (step> conf.max_step) {
					step = conf.max_step;
				}else if (step < conf.min_step) {
					step = conf.min_step;
				}
	            
	            if (f - old_f < 0) {
					step *= 0.5;
					for (int i = 0; i < num_feature; i++) {
						lambda[i] = old_lambda[i];		//走错，还原上一次的状态
					}
				}else {
					step *= 1.2;
					for (int i = 0; i < num_feature; i++) {
						old_lambda[i] = lambda[i];
					}
					
					for (int i = 0; i < num_feature; i++)	  
		                lambda[i] 	+=  gradient[i] * step;
					
					
				}
	            
	            
	            
			}
			
			
			
			
			flog.flush();
			flog.close();
			
			saveResult( num_iter);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }

    void train2(){
    	//init train
    	genFeature();
    	loadData(conf.nodeFile, conf.edgeFile);		//change to config type
    	factor_graph.GenPropagateOrder();
    	
    	//start train
    	double[] gradient = new double[num_feature];
    	double[] G = new double[num_feature];
    	
    	for (int i = 0; i < num_feature; i++) {
    		G[i] = Math.abs(lambda[i]);
		}
    	
    	double f; // log-likelihood
    	
    	double eta = conf.gradient_step;
    	double eps = 1e-8;
    	
    	double old_f = 0.0;
    	
    	int num_iter;
    	double step = conf.gradient_step;
    	try {
			FileWriter flog=  new FileWriter(conf.likelihood_log);
			num_iter = 0;
			boolean saveResult = false;
			boolean flag = false;
			
			int sameStep = 0;
			while(num_iter < conf.max_iter){
				num_iter ++;
				if (num_iter%10==0) {
					saveResult = true;
				}else {
					saveResult = false;
				}
				f = CalcGradient(gradient,saveResult,num_iter);
				
				
//				for (int i = 0; i < gradient.length; i++) {
//					if (Double.isNaN(gradient[i])) {
//						System.err.println("NAN: gradient "+ i);
//					}
//				}
				System.out.printf("[Iter %4d] log-likelihood : %.8f\n", num_iter, f);
				String fString = String.format("[Iter %4d] log-likelihood : %.8f\n", num_iter, f);
				flog.write(fString);
				
				if (Math.abs(old_f - f) < conf.eps) {
					sameStep ++;
					if (sameStep==10) {
						break;
					}
				
					
				}
//				if (computeNorm(lambda, old_lambda)<conf.eps && num_iter>10) {
//					break;
//				}
		        old_f = f;
			     
		        
//		        f *=-1;
		     // Normalize Graident
	            double g_norm = 0.0;
	            for (int i = 0; i < num_feature; i++)
	                g_norm += gradient[i] * gradient[i];
	            g_norm = Math.sqrt(g_norm);
	            
	            if (g_norm > 1e-8)
	            {
	                for (int i = 0; i < num_feature; i++)
	                    gradient[i] /= g_norm;
	            }
	            
//	            if (flag) {
//					conf.gradient_step *= 1.5;
//				}else {
//					conf.gradient_step *= 0.9;
//				}
//	            if (num_iter==100) {
//					conf.gradient_step /=2;
//				}
//	            if (step> conf.max_step) {
//					step = conf.max_step;
//				}else if (step < conf.min_step) {
//					step = conf.min_step;
//				}
	            
	            for (int i = 0; i < num_feature; i++) {
					lambda[i] += eta/Math.sqrt(G[i] + eps) * gradient[i];
					
					G[i] = Math.sqrt(Math.pow(G[i], 2) + Math.pow(lambda[i], 2));
				}
	            
	            
	            
	            
	            
			}
			
			
			
			
			flog.flush();
			flog.close();
			
			saveResult( num_iter);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }
    
    
   
    
    private double computeNorm(double[] vec1, double[] vec2 ) {
		// TODO Auto-generated method stub
    	double result = 0;
    	for (int i = 0; i < vec1.length; i++) {
			result += Math.pow(vec1[i]-vec2[i], 2);
		}
    	result = Math.sqrt(result);
    	
    	return result;
	}

	double CalcGradient(double[] gradient, boolean saveResult, int iter) {
		// TODO Auto-generated method stub
		double f = 0;
		
		for (int i = 0; i <num_feature; i++) {
			gradient[i] = 0;
		}
		
		//Calculation
		/*
		 * Belief Propagation 1: labeled data are given.
		 */
		factor_graph.labeled_given = true;
		factor_graph.ClearDataForSumProduct();
		
		//set state_factor
		for (int i = 0; i < factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			for (int y = 0; y < num_label; y++) {
				if (vNode.label_type ==1 && vNode.y != y) {		//if not the same type
					vNode.state_factor[y] = 0;
				}else{
					double v = 1;
					for (int t = 0; t < num_attrib; t++) {
						v *= Math.exp(lambda[t + y*num_attrib]* vNode.feature[t]);
					}
					vNode.state_factor[y] = v;
				}
			}
		}
		
		
		
		
		factor_graph.BeliefPropagation(conf.max_bp_iter);
		factor_graph.CalculateMarginal();
		
		
		//debug
//		//print belief
//		 try {
//			FileWriter fw = new FileWriter("model/temp/belief.txt");
//			
//			 for (int i = 0; i < factor_graph.num_node; i++) {
//					Node node = FactorGraph.nodes.get(i);
//					String beliefString = "";
//					for (int j = 0; j < node.belief.size(); j++) {
//						for (int j2 = 0; j2 < num_label; j2++) {
//							beliefString +=node.belief.get(j)[j2]+" ";
//						}
//						beliefString +=",";
//					}
//					
//					fw.write(beliefString+"\n");
//			}
//			 
//			 fw.flush();
//			 fw.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		 
//		System.exit(0);
		
		/*
		 * Gradient = E_{Y|Y_L} f_i - E_{Y} f_i
		 */
		
		//calc gradient part : + E_{Y|Y_L} f_i
		//for variable node
		for (int i = 0; i < factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			for (int y = 0; y < num_label; y++) {
				for (int t = 0; t < num_attrib; t++) {
					gradient[t + y*num_attrib ] +=  vNode.feature[t] * vNode.marginal[y];
					
//					System.out.println(vNode.feature[t]+" * " + vNode.marginal[y]+" = "+vNode.feature[t] * vNode.marginal[y]);
//					if (Double.isNaN(gradient[t + y*num_attrib])) {
//						break;
//					}
					
				}
			}
		}
		
		//debug
		for (int i = 0; i < gradient.length; i++) {
			if (Double.isNaN(gradient[i])) {
				System.err.println("NAN:  after  Gradient = E_{Y|Y_L} f_i - E_{Y} f_i   variable node"+i);
				break;
			}
		}
		
		//for factor node
		for (int i = factor_graph.n; i < factor_graph.num_node; i++) {
			FactorNode fNode = (FactorNode) FactorGraph.nodes.get(i);
			
			if (fNode.neighbor_pos.size()==2) {
				for (int a = 0; a < num_label; a++) {
					for (int b = 0; b < num_label; b++) {	
//						System.out.println(gradient.length+" "+a+","+b+" -> "+ getEdgeParamenterId(fNode.func_type, a, b));
						gradient[getEdgeParamenterId(fNode.func_type, a, b)] += fNode.marginal[a][b];
					}
				}
			}
		}
		
		//debug
		for (int i = 0; i < gradient.length; i++) {
			if (Double.isNaN(gradient[i])) {
				System.err.println("NAN:  after  Gradient = E_{Y|Y_L} f_i - E_{Y} f_i   factor node");
				break;
			}
		}
		
		
		 /*
		  * Belief Propagation 2: labeled data are not given.
		  */
		factor_graph.ClearDataForSumProduct();
		factor_graph.labeled_given  = false;
		
		//set state_factor for variable node
		//the same as before (can create another methods setStateFactor for this)
		for (int i = 0; i < factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			for (int y = 0; y < num_label; y++) {
				
					double v = 1;
					for (int t = 0; t < num_attrib; t++) {
						v *= Math.exp(lambda[t + y*num_attrib]* vNode.feature[t]);
					}
					vNode.state_factor[y] = v;
				
			}
		}
		
		factor_graph.BeliefPropagation(conf.max_bp_iter);
		factor_graph.CalculateMarginal();
		
		//calc gradient part : - E_{Y} f_i
		//for variable node
		for (int i = 0; i < factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			for (int y = 0; y < num_label; y++) {
				for (int t = 0; t < num_attrib; t++) {
					gradient[t + y*num_attrib ] -=  vNode.feature[t] * vNode.marginal[y];
				}
			}
		}
		
		
		//debug
		for (int i = 0; i < gradient.length; i++) {
			if (Double.isNaN(gradient[i])) {
				System.err.println("NAN:  after  - E_{Y} f_i   varible node");
				break;
			}
		}
		
		//for factor node
		for (int i = factor_graph.n; i < factor_graph.num_node; i++) {
			FactorNode fNode = (FactorNode) FactorGraph.nodes.get(i);
			
			if (fNode.neighbor_pos.size()==2) {
				for (int a = 0; a < num_label; a++) {
					for (int b = 0; b < num_label; b++) {
						gradient[getEdgeParamenterId(fNode.func_type, a, b)] -= fNode.marginal[a][b];
					}
				}
			}
		}		
		
		//debug
		for (int i = 0; i < gradient.length; i++) {
			if (Double.isNaN(gradient[i])) {
				System.err.println("NAN:  after  - E_{Y} f_i   factor node");
				break;
			}
		}
		
		
		//gradient calculation complete
	    // Calculate gradient & log-likelihood
		f = 0;
		double Z = 0.0;
		// \sum \lambda_i * f_i
		for (int i = 0; i < factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			int y = vNode.y;
			for (int t = 0; t < num_attrib; t++) {
				f += lambda[y*num_attrib + t]*vNode.feature[t];
			}
		}
		
		for (int i = factor_graph.n; i < factor_graph.n + factor_graph.m; i++) {
			FactorNode fNode = (FactorNode) FactorGraph.nodes.get(i);
			Integer[] neighbor = fNode.neighbor_pos.keySet().toArray(new Integer[2]);
			int a = ((VariableNode)FactorGraph.nodes.get(neighbor[0])).y;
			int b = ((VariableNode)FactorGraph.nodes.get(neighbor[1])).y;
			f += lambda[getEdgeParamenterId(fNode.func_type, a, b)];
		}
		
		// calc log-likelihood
	    //  using Bethe Approximation
		for (int i = 0; i < factor_graph.n; i++){
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
	        for (int y = 0; y < num_label; y ++){
	            for (int t = 0; t <num_attrib; t ++)
	                Z += lambda[y*num_attrib + t] * vNode.feature[t] * vNode.marginal[y];
	        }
	    }
		
		for (int i = factor_graph.n; i < factor_graph.n + factor_graph.m; i++) {
			FactorNode fNode = (FactorNode) FactorGraph.nodes.get(i);
			if (fNode.belief.size()==2) {
				for (int a = 0; a < num_label; a ++)
					for (int b = 0; b < num_label; b ++){
						Z += lambda[getEdgeParamenterId(fNode.func_type, a, b)]* fNode.marginal[a][b];
					}
			}
			if (fNode.belief.size()==3) {
				
			}
		}
		
		
		// Edge entropy
		for (int i = factor_graph.n; i < factor_graph.n + factor_graph.m; i++) {
			FactorNode fNode = (FactorNode) FactorGraph.nodes.get(i);
			
			double h_e = 0.0;
			if (fNode.belief.size()==2) { 
				for (int a = 0; a < num_label; a ++)
					for (int b = 0; b < num_label; b ++){
						if (fNode.marginal[a][b] > 1e-10) {
							h_e += - fNode.marginal[a][b]*Math.log(fNode.marginal[a][b]);
						}
					}
			}
			if (fNode.belief.size()==3) {
				
			}
			
			Z += h_e;
		}
		
		//Node entroy
		for (int i = 0; i < factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			
			double h_v = 0.0;
			for (int a = 0; a < vNode.num_label; a++) {
				if (Math.abs(vNode.marginal[a]) > 1e-10) {
					h_v += - vNode.marginal[a] * Math.log(vNode.marginal[a]);
				}
			}
			Z -= h_v * (vNode.belief.size()-1);
		}
		
		f -=Z;
		
		if (saveResult) {
			saveResult(iter);
		}
		 
		 
		return f;
	}
	 
	
	//iter : number of iteration
	void saveResult(int iter){
		// Let's take a look of current accuracy
				factor_graph.ClearDataForSumProduct();
				factor_graph.labeled_given = false;
				setStateFactor();
				
				factor_graph.MaxSumPropagation(conf.max_bp_iter);
				
				double[][] label_prob = new double[num_label][factor_graph.n];
				
				try {
					String probFile = conf.probability_w.replace(".txt", "_"+iter+".txt");
					FileWriter fprob = new FileWriter(probFile);	//add to end
					
					FileWriter flog = new FileWriter(conf.train_log, true);
					int[] inf_label = new int[factor_graph.n];
					flog.write("+----------------------------------------+");
					flog.write("iter: "+ iter+"\n");
					
					for (int i = 0; i < factor_graph.n; i++) {
						int ybest =-1;
						double vbest = -1, v ;
						double vsum = 0;
						VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
						
						for (int y = 0; y < num_label; y++) {
							v = vNode.state_factor[y];
							for (int t = 0; t < vNode.belief.size(); t++) {
								v *= vNode.belief.get(t)[y];
							}
							
							if (ybest < 0 || v > vbest) {
								ybest= y;
								vbest = v;
							}
							
							label_prob[y][i]  = v;
							vsum += v;					
						}
						
						for (int y = 0; y < num_label; y++) {
							label_prob[y][i] /= vsum;
						}
						
						inf_label[i] = ybest;				
					}
					
					for (int i = 0; i < factor_graph.n; i++) {
						if (((VariableNode) FactorGraph.nodes.get(i)).label_type == 1) {
							for (int y = 0; y < num_label; y++) {
//								fprob.write("-1 ");
								fprob.write(label_prob[y][i]+" ");
							}
							fprob.write("\n");
						}else {
							for (int y = 0; y < num_label; y++) {
								fprob.write(label_prob[y][i]+" ");
							}
							fprob.write("\n");
						}
						
						if (i%10000==0) {
							fprob.flush();
						}
					}
					
					
					label_prob = null;
					
					fprob.flush();
					fprob.close();
					

					int hit = 0, miss = 0;
				    int hitu = 0, missu = 0;
				    
				    int[][] cnt = new int[num_label][num_label];
				    int[][] ucnt = new int[num_label][num_label];  //for unlabeled
				    
				    for (int i = 0; i < factor_graph.n; i++) {
				    	VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
				    	
				    	int label = vNode.y;
				    	if (inf_label[i] == label) {
							hit++;
						}else {
							miss++;
						}
				    	
//				    	cnt[inf_label[i]][label]++;	
				    	cnt[label][inf_label[i]]++;	
				    	
				    	if (vNode.label_type == 0) {
							if (inf_label[i] == label) {
								hitu++;
							}else {
								missu++;
							}
							
//							ucnt[inf_label[i]][label]++;
							ucnt[label][inf_label[i]]++;
						}
					}
				    
				 
				    	System.out.printf("A_HIT  = %6d, U_HIT  = %4d\n", hit, hitu);//all hit
					    System.out.printf("A_MISS = %6d, U_MISS = %4d\n", miss, missu);
					
				    
				    
			//	    System.out.println("A_HIT  = "+hit+", U_HIT  = "+hitu+"\n");	//all hit
			//	    System.out.println("A_MISS  = "+miss+", U_MISS  = "+missu+"\n");
				    
				    String hitString = String.format("A_HIT  = %6d, U_HIT  = %4d\n", hit, hitu);
					String missString = String.format("A_MISS = %6d, U_MISS = %4d\n", miss, missu);
				    flog.write(hitString+missString);
				  
				    	String ttString = "";
						double[] type_count = new double[num_label];
						double[] t_p = new double[num_label];
						double[] t_r = new double[num_label];
						double[] t_f = new double[num_label];
						double accu_up = 0;
						double accu_down = 0;
						for (int l = 0; l < num_label; l++) {
							double sum = 0;
							for (int t = 0; t < num_label; t++) {
								sum += cnt[t][l];
							}
							if (sum==0) {
								t_p[l] = 0;
							}else {
								t_p[l] = (double) cnt[l][l]/ sum;
							}
							
							
							sum = 0;
							for (int t = 0; t < num_label; t++) {
								sum += cnt[l][t];
							}
							if (sum==0) {
								t_r[l] = 0;
							}else {
								t_r[l] = (double)cnt[l][l]/sum;
							}
							
							type_count[l] = sum;
							accu_up +=cnt[l][l];
							accu_down += sum;
							if ((t_p[l]+t_r[l])==0) {
								t_f[l] = 0;
							}else {
								t_f[l] = 2 * t_p[l] * t_r[l] / (t_p[l] + t_r[l]);
							}
							
							
							
								System.out.printf("%d   %.4f   %.4f   %.4f\n", l, t_p[l], t_r[l], t_f[l]);
								String aResultString = String.format("%d   %.4f   %.4f   %.4f\n", l, t_p[l], t_r[l], t_f[l]);
								flog.write(aResultString);
							
						}
						double accuracy = accu_up/accu_down;
						double w_p  = 0;
						double w_r  = 0;
						double w_f  = 0;
						for (int t = 0; t < num_label; t++) {
							w_p += t_p[t] * type_count[t];
							w_r += t_r[t] * type_count[t];
							w_f += t_f[t] * type_count[t];
						}
						w_p /= accu_down;
						w_r /= accu_down;
						w_f /= accu_down;
						
						
							System.out.printf("A_Accuracy  = %.4f    ", accuracy);
							System.out.printf("A_Precision = %.4f    ", w_p);
							System.out.printf("A_Recall    = %.4f    ", w_r);
							System.out.printf("A_F1        = %.4f\n", w_f);
							ttString = String.format("A_Accuracy  = %.4f    ", accuracy);
							ttString += String.format("A_Precision = %.4f    ", w_p);
							ttString += String.format("A_Recall    = %.4f    ", w_r);
							ttString += String.format("A_F1        = %.4f\n", w_f);
							flog.write(ttString);
						
						accu_up = 0;
						accu_down = 0;
						//unlabeled
						for (int l = 0; l < num_label; l++) {
							double sum = 0;
							for (int t = 0; t < num_label; t++) {
								sum += ucnt[t][l];
							}
							if (sum==0) {
								t_p[l] = 0;
							}else {
								t_p[l] = (double) ucnt[l][l]/ sum;
							}
							
							
							sum = 0;
							for (int t = 0; t < num_label; t++) {
								sum += ucnt[l][t];
							}
							if (sum==0) {
								t_r[l] = 0;
							}else {
								t_r[l] = (double)ucnt[l][l]/sum;
							}
							
							type_count[l] = sum;
							accu_up +=ucnt[l][l];
							accu_down += sum;
							
							if ((t_p[l]+t_r[l])==0) {
								t_f[l] = 0;
							}else {
								t_f[l] = 2 * t_p[l] * t_r[l] / (t_p[l] + t_r[l]);
							}
//							t_f[l] = 2 * t_p[l] * t_r[l] / (t_p[l] + t_r[l]);
							
						
								System.out.printf("%d   %.4f   %.4f   %.4f\n", l, t_p[l], t_r[l], t_f[l]);
								String aResultString = String.format("%d   %.4f   %.4f   %.4f\n", l, t_p[l], t_r[l], t_f[l]);
								flog.write(aResultString);
							
						}
						 accuracy = accu_up/accu_down;
						 w_p  = 0;
						 w_r  = 0;
						 w_f  = 0;
						for (int t = 0; t < num_label; t++) {
							w_p += t_p[t] * type_count[t];
							w_r += t_r[t] * type_count[t];
							w_f += t_f[t] * type_count[t];
						}
						w_p /= accu_down;
						w_r /= accu_down;
						w_f /= accu_down;
						
					
							System.out.printf("U_Accuracy  = %.4f    ", accuracy);
							System.out.printf("U_Precision = %.4f    ", w_p);
							System.out.printf("U_Recall    = %.4f    ", w_r);
							System.out.printf("U_F1        = %.4f\n", w_f);
							ttString = String.format("U_Accuracy  = %.4f    ", accuracy);
							ttString += String.format("U_Precision = %.4f    ", w_p);
							ttString += String.format("U_Recall    = %.4f    ", w_r);
							ttString += String.format("U_F1        = %.4f\n", w_f);
							flog.write(ttString);
						
						
					
					
					/*
					int hit = 0, miss = 0;
				    int hitu = 0, missu = 0;
				    
				    int[][] cnt = new int[num_label][num_label];
				    int[][] ucnt = new int[num_label][num_label];  //for unlabeled
				    
				    for (int i = 0; i < factor_graph.n; i++) {
				    	VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
				    	
				    	int label = vNode.y;
				    	if (inf_label[i] == label) {
							hit++;
						}else {
							miss++;
						}
				    	
				    	cnt[inf_label[i]][label]++;		    	
				    	
				    	if (vNode.label_type == 0) {
							if (inf_label[i] == label) {
								hitu++;
							}else {
								missu++;
							}
							
							ucnt[inf_label[i]][label]++;
						}
					}
				    
				    
				    System.out.printf("A_HIT  = %6d, U_HIT  = %4d\n", hit, hitu);//all hit
				    System.out.printf("A_MISS = %6d, U_MISS = %4d\n", miss, missu);
				    
//				    System.out.println("A_HIT  = "+hit+", U_HIT  = "+hitu+"\n");	//all hit
//				    System.out.println("A_MISS  = "+miss+", U_MISS  = "+missu+"\n");
				    String hitString = String.format("A_HIT  = %6d, U_HIT  = %4d\n", hit, hitu);
					String missString = String.format("A_MISS = %6d, U_MISS = %4d\n", miss, missu);
				    flog.write(hitString+missString);
				    
				    double a_precision = 0;
				    double a_recall = 0;
				    double a_fmeasure = 0;
				    System.out.printf("A_Accuracy  = %.4f\n", (double)hit / (hit + miss));
				    
				    for (int k = 0; k < num_label; ++k)
					{
						double srow = 0, scolumn = 0;
						for (int i = 0; i < num_label; ++i)
						{
							srow += cnt[k][i];
							scolumn += cnt[i][k];
						}
						a_precision = (double)cnt[k][k] / srow;
						a_recall = (double)cnt[k][k] / scolumn;
						a_fmeasure = 2.0 * a_precision * a_recall / (a_precision + a_recall);
						System.out.printf("%d   %.4f   %.4f   %.4f\n", k, a_precision, a_recall, a_fmeasure);
						String aResultString = String.format("%d   %.4f   %.4f   %.4f\n", k, a_precision, a_recall, a_fmeasure);
						flog.write(aResultString);
					}
				    System.out.printf("U_Accuracy  = %.4f\n", (double)hitu / (hitu + missu));
				    String U_Accuracy = String.format("U_Accuracy  = %.4f\n", (double)hitu / (hitu + missu));
				    flog.write(U_Accuracy);
				    
				    double u_precision = 0;
				    double u_recall = 0;
				    double u_fmeasure = 0;
				    
					double total_target = 0;
					double total_row = 0;
					double total_column = 0;
				    
				    for (int k = 0; k < num_label; ++k)
					{
						double srow = 0, scolumn = 0;
						for (int i = 0; i < num_label; ++i)
						{
							srow += ucnt[k][i];
							scolumn += ucnt[i][k];
						}
						u_precision = (double)ucnt[k][k] / srow;
						u_recall = (double)ucnt[k][k] / scolumn;
						u_fmeasure = 2.0 * u_precision * u_recall / (u_precision + u_recall);
						System.out.printf("%d   %.4f   %.4f   %.4f\n", k, u_precision, u_recall, u_fmeasure);
						String fileOutString = String.format("%d   %.4f   %.4f   %.4f\n", k, u_precision, u_recall, u_fmeasure);
						flog.write(fileOutString);
						total_target += ucnt[k][k];
						total_row += srow;
						total_column += scolumn;
					}
				    double precision = (double) total_target / total_row;
					double recall = (double) total_target / total_column;
					double fmeasure = (double) 2.0 * precision * recall / (precision + recall);
					System.out.printf("Total :   %.4f   %.4f   %.4f\n\n", precision, recall, fmeasure);
					String totalResult = String.format("Total :   %.4f   %.4f   %.4f\n\n", precision, recall, fmeasure);
					flog.write(totalResult);
					*/
					flog.flush();
					flog.close();
					
					saveModel(String.valueOf(iter));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} //		
	}
 	 
	void saveModel(String iter){
		try {
			String FileModel = conf.dst_model_file.replace(".txt", iter+".txt");
			FileWriter fmodel = new FileWriter(FileModel);
			
			fmodel.write(num_feature+"\n");
			for (int i = 0; i <  num_feature; i++) {
				fmodel.write(lambda[i]+" ");
			}
			fmodel.flush();
			fmodel.close();
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	int getEdgeParamenterId(int edge_type, int a, int b) {
		
		int offset =edge_feature_offset.get(a * num_label + b);
		
		return num_attrib_parameter + edge_type*num_edge_feature_each_type + offset;
	}
	
	void setStateFactor(){
		for (int i = 0; i <factor_graph.n; i++) {
			VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
			for (int y = 0; y < num_label; y++) {
//				if (vNode.label_type ==1 && vNode.y != y) {		//if not the same type
//					vNode.state_factor[y] = 0;
//				}else{
					double v = 1;
					for (int t = 0; t < num_attrib; t++) {
						v *= Math.exp(lambda[t + y*num_attrib]* vNode.feature[t]);
					}
					vNode.state_factor[y] = v;
//				}
			}
		}
	}
    

	public void printRealLabel() {
		FileWriter rL;
		try {
			rL = new FileWriter("real_label0.txt");
			
			//write label_prob[][]
			int tc = 0;
			String realString = "";
			for (int i = 0; i < factor_graph.n; i++) {
				VariableNode vNode = (VariableNode) FactorGraph.nodes.get(i);
				
				
				rL.write(vNode.y+"\n");
			}
			rL.flush();
			rL.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	 void log_debug() {
		// TODO Auto-generated method stub
		//print belief
		 try {
			FileWriter fw = new FileWriter("/temp/belief.txt");
			
			 for (int i = 0; i < factor_graph.num_node; i++) {
					Node node = factor_graph.nodes.get(i);
					String beliefString = "";
					for (int j = 0; j < node.belief.size(); j++) {
						for (int j2 = 0; j2 < num_label; j2++) {
							beliefString +=node.belief.get(j)[j2]+" ";
						}
						beliefString +=",";
					}
					
					fw.write(beliefString+"\n");
			}
			 
			 fw.flush();
			 fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
