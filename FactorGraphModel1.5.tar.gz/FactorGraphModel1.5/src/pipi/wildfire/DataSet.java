package pipi.wildfire;

public class DataSet {

	public int num_label_id;
	
	
}
