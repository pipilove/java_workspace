package pipi.basicfgm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

public class DataPre {

	
	
	private void extract_idset_nodes(String basedir) {
		// TODO Auto-generated method stub
		String file_nodes = basedir + "nodes_idnet.txt";
		String out_idset = basedir + "idset_final.txt";
		String out_nodes = basedir + "data\\nodes_final.txt";
		
		try {
			Scanner scanner = new Scanner(new File(file_nodes));
			
			PrintWriter pw_idset = new PrintWriter(out_idset);
			PrintWriter pw_nodes = new PrintWriter(out_nodes);
			
			Random random = new Random(3);
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				
				StringBuffer aBuffer = new StringBuffer();
			
				double prior = Double.valueOf(tpStrings[2]);
				if (tpStrings[1].startsWith("u_")) {
					//for user network
//					if (prior > 0) {
//						pw_idset.println(tpStrings[1]);
//					}else {
//						continue;
//					}
					pw_idset.println(tpStrings[1]);
					
				}else {
					//for location network
					pw_idset.println(tpStrings[1]);
				}
				
				
				if (tpStrings[1].startsWith("l_")) {
//					if (prior>0.9) {
//						aBuffer.append("+,1");
//					}else {
//						aBuffer.append("+,0");
//					}
					
					if (prior==0) {
						aBuffer.append("+,0");
					}else {
						aBuffer.append("+,1");
					}
				}else {
					if (prior == 0) {
						aBuffer.append(tpStrings[0] + ",0");						
					}else {
						aBuffer.append(tpStrings[0] + ",1");
					}
				}
				
				for (int i = 3; i < tpStrings.length; i++) {
					aBuffer.append(","+tpStrings[i]);
				}
				
				pw_nodes.println(aBuffer.toString());
			}
			
			pw_idset.flush();
			pw_idset.close();
			
			pw_nodes.flush();
			pw_nodes.close();
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	
	private void extract_idset_nodes1(String basedir) {
		// TODO Auto-generated method stub
		String file_nodes = basedir + "nodes_idnet.txt";
		String out_idset = basedir + "idset_final.txt";
		String out_nodes = basedir + "data\\nodes_final.txt";
		
		try {
			Scanner scanner = new Scanner(new File(file_nodes));
			
			PrintWriter pw_idset = new PrintWriter(out_idset);
			PrintWriter pw_nodes = new PrintWriter(out_nodes);
			
			Random random = new Random(3);
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				
				StringBuffer aBuffer = new StringBuffer();
			
				double prior = Double.valueOf(tpStrings[2]);
				if (tpStrings[1].startsWith("u_")) {
					//for user network
//					if (prior > 0) {
//						pw_idset.println(tpStrings[1]);
//					}else {
//						continue;
//					}
					pw_idset.println(tpStrings[1]);
					
				}else {
					//for location network
					pw_idset.println(tpStrings[1]);
				}
				
				
				if (tpStrings[1].startsWith("l_")) {
					if (prior>0.9) {
						aBuffer.append("+,1");
					}else {
						aBuffer.append("+,0");
					}
				}else {
					if (prior > 140) {
						
						if (prior > 200) {
							
//							if (random.nextDouble() < 0.7) {
//								aBuffer.append("+,1");
//							}else {
//								aBuffer.append("?,1");
//							}
							aBuffer.append("+,1");
							
						}else {
							aBuffer.append("?,1");
						}
						
					}else {
						
						if (prior < 90) {
							
								aBuffer.append("+,0");
							
						}else if(prior > 0){
							aBuffer.append("?,0");
						}else {
							aBuffer.append("+,0");
						}
					}
				}
				
				for (int i = 3; i < tpStrings.length; i++) {
					aBuffer.append(","+tpStrings[i]);
				}
				
				pw_nodes.println(aBuffer.toString());
			}
			
			pw_idset.flush();
			pw_idset.close();
			
			pw_nodes.flush();
			pw_nodes.close();
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private void train_test_count(String basedir) {
		// TODO Auto-generated method stub
		String file_nodes = basedir + "data\\nodes.txt";
		
		double[] count = new double[2];
		try {
			Scanner scanner = new Scanner(new File(file_nodes));
			double num_instance = 0;
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String type = lineString.split(",")[0];
				
				if (type.equals("+")) {
					count[0]++;
				}else {
					count[1]++;
				}
				num_instance++;
			}
			scanner.close();
			
			System.out.println(count[0]+"\n" +  count[1]);
			System.out.println("\n"+ count[0]/num_instance + "\n"+ count[1]/num_instance);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void filter_network(String basedir) {
		// TODO Auto-generated method stub
		String file_idset = basedir + "idset.txt";
		String file_network = basedir + "metapath.txt";
		String out_idset_net = basedir + "idset_net.txt";
		String out_net = basedir + "network.txt";
		
		HashSet<String> idSet = new HashSet<>();
		ArrayList<String> idList = new ArrayList<>();
		
		HashSet<String> net_idSet = new HashSet<>();
		
		try {
			Scanner scanner = new Scanner(new File(file_idset));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				idSet.add(lineString);
				idList.add(lineString);
			}
			scanner.close();
			
			PrintWriter pw_net = new PrintWriter(out_net);
			scanner = new Scanner(new File(file_network));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				if (idSet.contains(tpStrings[0]) &&  idSet.contains(tpStrings[1])) {
					pw_net.println(lineString);
					net_idSet.add(tpStrings[0]);
					net_idSet.add(tpStrings[1]);
				}
			}
			scanner.close();
			
			
			pw_net.flush();
			pw_net.close();
			
			PrintWriter pw_idset = new PrintWriter(out_idset_net);
			
			for (String idString : net_idSet) {
				pw_idset.println(idString);
			}
			pw_idset.flush();
			pw_idset.close();
			
			
		} catch (IOException e) {
			// TODO: handle exception
		}
		
	}
	
	private void read_lines(String basedir) {
		// TODO Auto-generated method stub
//		String file_network = basedir + "metapath.txt";
		String file_network = basedir + "network.txt";
		
		try {
			Scanner scanner = new Scanner(new File(file_network));
			
			
			int k = 0;
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				
				System.out.println(lineString);
				if (k++==20) {
					break;
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	

	private void user_from_meta_path(String basedir) {
		// TODO Auto-generated method stub
		String file_metapath = basedir + "metapath.txt";
		String out_idset_metapath = basedir + "idset_metapath.txt";
		
		HashSet<String> idSet = new HashSet<>();
		try {
			Scanner scanner = new Scanner(new File(file_metapath));
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				idSet.add(tpStrings[0]);
				idSet.add(tpStrings[1]);
			}
			scanner.close();
			
			FileWriter fw = new FileWriter(out_idset_metapath);
			
			for (String idString : idSet) {
				fw.write(idString + "\n");
			}
			
			fw.flush();
			fw.close();
			
		} catch (IOException e) {
			// TODO: handle exception
		}
		
	}
	
	private void meta_path_count(String basedir) {
		// TODO Auto-generated method stub
//		String file_network = basedir + "metapath.txt";
		String file_network = basedir + "idset_net.txt";
//		String file_network = basedir + "idset.txt";
//		String file_network = basedir + "idser_metapath.txt";
		
		double[] count = new double[2];
		
		try {
			Scanner scanner = new Scanner(new File(file_network));
			
			
			int k = 0;
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				
//				String[] tpStrings = lineString.split(",");
				if (lineString.startsWith("l_")) {
					count[0]++;
				}else {
					count[1]++;
				}
				k++;
				
				
			}
			
			System.out.println(count[0]+"\n" +  count[1]);
			System.out.println("\n"+ count[0]/k + "\n"+ count[1]/k);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	private void nodes2netidset(String basedir) {
		// TODO Auto-generated method stub
		String file_idset = basedir + "idset_net.txt";
		String file_nodes = basedir + "nodes.txt";
		
		String out_nodes = basedir + "nodes_idnet.txt";
		
		try {
			HashSet<String> idSet = new HashSet<>();
			Scanner scanner = new Scanner(new File(file_idset));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				idSet.add(lineString);
			}
			scanner.close();
			
			FileWriter fw = new FileWriter(out_nodes);
			
			scanner =  new Scanner(new File(file_nodes));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				if (idSet.contains(tpStrings[1])) {
//					fw.write(tpStrings[0] + "," + tpStrings[1]+","+tpStrings[2]+"\n");
					fw.write(lineString + "\n");
				}
				
			}
			scanner.close();
			fw.flush();
			fw.close();
			
			
			
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	
	private void idset_filtered(String basedir) {
		// TODO Auto-generated method stub
		

	}
	
	private void idset_from_nodes(String basedir) {
		// TODO Auto-generated method stub
		String file_nodes = basedir + "nodes.txt";
		String out_idset = basedir + "idset.txt";
		
		try {
			Scanner scanner = new Scanner(new File(file_nodes));
			PrintWriter pw = new PrintWriter(new File(out_idset));
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String idString = lineString.split(",")[1];
				pw.println(idString);
			}
			scanner.close();
			pw.flush();
			pw.close();
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private void net_reid(String basedir) {
		// TODO Auto-generated method stub
		String file_idset = basedir + "idset_final.txt";
		String file_network = basedir + "network.txt";
		
		String out_net_reid = basedir + "network_reid.txt";
		String out_edges = basedir + "data\\edges.txt";
		
		try {
			HashMap<String, Integer> idMap = new HashMap<>();
			int k =0;
			Scanner scanner = new Scanner(new File(file_idset));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				idMap.put(lineString, k++);
			}
			scanner.close();
			
			PrintWriter pw_net = new PrintWriter(out_net_reid);
			PrintWriter pw_edge = new PrintWriter(out_edges);
			
			scanner = new Scanner(new File(file_network));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				Integer id1 = idMap.get(tpStrings[0]);
				Integer id2 = idMap.get(tpStrings[1]);
				
				pw_net.println(id1+","+id2+",0");
				pw_edge.println("#edge,"+id1+","+id2+",0");
			}
			scanner.close();
			pw_net.flush();
			pw_net.close();
			
			pw_edge.flush();
			pw_edge.close();
			
			
		} catch (IOException e) {
			// TODO: handle exception
		}
		
	}
	
	private void count_lines(String fileString) {
		// TODO Auto-generated method stub
		
	}
	
	private void nb_count(String basedir) {
		// TODO Auto-generated method stub
		String file_idset = basedir + "idset_final.txt";
		String file_network = basedir + "metapath.txt";
		
		String out_nb_count = basedir + "nb_count.txt";
		HashMap<String, Integer> nb_countMap = new HashMap<>();
		ArrayList<String> idList = new ArrayList<>();
		
		try {
			Scanner scanner = new Scanner(new File(file_idset));
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				idList.add(lineString);
			}
			scanner.close();
			
			scanner = new Scanner(new File(file_network));
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				
				if (nb_countMap.containsKey(tpStrings[0])) {
					Integer value = nb_countMap.get(tpStrings[0]);
					nb_countMap.put(tpStrings[0], ++value);
				}else {
					nb_countMap.put(tpStrings[0], 1);
				}
				
				if (nb_countMap.containsKey(tpStrings[1])) {
					Integer value = nb_countMap.get(tpStrings[1]);
					nb_countMap.put(tpStrings[1], ++value);
				}else {
					nb_countMap.put(tpStrings[1], 1);
				}
			}
			scanner.close();
			
			PrintWriter pw = new PrintWriter(out_nb_count);
			for (int i = 0; i < idList.size(); i++) {
				String uid = idList.get(i);
				
				Integer count = nb_countMap.get(uid);
				pw.println(uid + ","+count);
			}
			pw.flush();
			pw.close();
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	private void gen_data_all(String basedir) {
		// TODO Auto-generated method stub
		idset_from_nodes(basedir);
		user_from_meta_path(basedir);
		filter_network(basedir);
		nodes2netidset(basedir);
		extract_idset_nodes(basedir);
		net_reid(basedir);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String basedir = "E:\\pipi\\";
		
		DataPre dataPre = new DataPre();
		
//		dataPre.extract_idset_nodes(basedir);
////		
//		dataPre.train_test_count(basedir);

		
//		dataPre.read_lines(basedir);
		
//		dataPre.meta_path_count(basedir);
		
//		dataPre.filter_network(basedir);
		
//		dataPre.idset_from_nodes(basedir);
//		dataPre.user_from_meta_path(basedir);
		
//		dataPre.nodes2netidset(basedir);
		
//		dataPre.net_reid(basedir);
		
//		dataPre.nb_count(basedir + "old3\\");
		
		dataPre.gen_data_all(basedir);
	}

}
