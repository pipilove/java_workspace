package pipi.basicfgm;

public class DataSet {

	public int num_label_id;
	
	
}
