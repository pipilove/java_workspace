package pipi.basicfgm;

public class Util {
	
	public static void DoubleArrFill(double[] array, double v){
		for (int i = 0; i < array.length; i++) {
			array[i] = v;
		}
	}
}


class Diff{
	double diff_max = 0;
}

class Lambda{
	
}