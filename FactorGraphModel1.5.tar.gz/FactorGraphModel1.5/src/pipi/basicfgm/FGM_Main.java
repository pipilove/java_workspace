package pipi.basicfgm;

public class FGM_Main {

	FGMModel fgmModel;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FGM_Main fgm_Main = new FGM_Main();
		
		Config conf = new Config();
		
		conf.max_iter = 1000;
		conf.max_bp_iter = 50;
		
		conf.task = "-est";
		
		conf.eps = 1e-6;
		conf.gradient_step = 0.05;
		conf.max_step = 0.1;
		conf.min_step = 0.001;
		
		conf.seed = 2;
		
//		conf.setWithRoot("G:\\research\\personality\\StatisticsTest\\big5Subnet\\FGM\\svd18352\\");
//		conf.setWithRoot("G:\\research\\personality\\StatisticsTest\\big5Subnet\\FGM\\svd18352_2of1\\");
		conf.setWithRootv2("E:\\dataSet\\cora\\cora\\");
//		conf.setWithRoot("");
		
//		conf.nodeFile = "model/data/nodes.txt";
//		conf.edgeFile = "model/data/edges.txt";
//		
//		conf.dst_model_file = "model/result/model.txt";
//		conf.probability_w = "model/result/probanility.txt";
//		conf.train_log = "model/result/train_log.txt";
//		conf.likelihood_log = "model/result/likelihood_log.txt";
		
		
		
		if (conf.task == "-est")
	    {
	        fgm_Main.Estimate(conf);
	    }
	    else if (conf.task == "-estc")
	    {
//	        EstimateContinue(conf);
	    }
	    else if (conf.task == "-inf")
	    {
//	        Inference(conf);
	    }
	    else
	    {
	        conf.ShowUsage();
	    }
		
	}

	private  void Estimate(Config conf) {
		// TODO Auto-generated method stub
		
//		int num_label = 2;
//		int num_edge_type = 1;
//		int num_attrib = 5;
//		int k = 5+5;	//#variable node + #factor node 
		
//
//		int num_label = 2;
////		int num_label = 5;
//		int num_edge_type = 1;
//		int num_attrib = 100;
//		int k = 18352+13712;	//#variable node + #factor node 
		
		
		int num_label = 2;
		int num_edge_type = 1;
		int num_attrib = 1433;
		int k = 2708+5429;
		
		
		
		fgmModel = new FGMModel();
		fgmModel.Init(num_label, num_edge_type, num_attrib, k, conf);
		
//		log_debug();
		
		fgmModel.train2();
		
		fgmModel.saveModel("final");
	}

	
	private void log_debug() {
		// TODO Auto-generated method stub
		System.out.println("Lambda:\n");
		String logString = "";
		for (int i = 0; i < fgmModel.num_feature; i++) {
			logString += fgmModel.lambda[i]+" ";
		}
		System.out.println(logString);
		
	}
}
