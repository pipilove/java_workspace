package pipi.fgm_prior;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Scanner;

public class FactorGraph {
	
	public static ArrayList<Node> nodes; 
	
	int n,m,num_label;
	
	int num_node;
	int num_feature;
	boolean converged;
	Diff diff;
	
	boolean labeled_given;
	int[] bfs_node ;
	
	
	
	/*
	 * InitGraph: initiate variable node first
	 * 
	 *  load node profile
	 *  n,m,num_label
	 *  id,feature
	 *  
	 *  k : the number of nodes, a round number for initiate
	 */
	void InitGraph( int num_label,int num_feature, int k){
//		this.n = n; //number of variable node
//		this.m = m; //number of factor node
		this.num_label = num_label;
		this.num_feature = num_feature;
		
		nodes = new ArrayList<>(k);
		diff = new Diff();

	}
	
	
	void GenPropagateOrder1(){
		num_node = nodes.size();
		bfs_node = new int[num_node];
		boolean[] mark  = new boolean[nodes.size()];
		
		for (int i = 0; i < nodes.size(); i++) {
			mark[i] = false;
		}
		
		int head = 0, tail = -1;
		int pos = 0;
		for (int i = 0; i < num_node; i++) {
			if (!mark[i]) {	//node not visited
				bfs_node[++tail] = i;
				mark[i] = true;
				
				while (head <= tail) {
					Node u = nodes.get(bfs_node[head++]);
					
					for(Integer neighbor_id : u.neighbor_pos.keySet()){
						if (!mark[neighbor_id]) {
							bfs_node[++tail] = neighbor_id;
							mark[neighbor_id] = true;
						}
					}
				}
			}
		}
		
		mark = null;	//release
	}

	void GenPropagateOrder(){
		num_node = nodes.size();
		bfs_node = new int[num_node];
		String file_order = "E:\\dataSet\\cora\\cora\\data\\pro_order.txt";
		
		try {
			Scanner scanner = new Scanner(new File(file_order));
			
			int k = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				
				bfs_node[k++] = Integer.valueOf(line);				
			}
			
			scanner.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

	
	
	void ClearDataForSumProduct(){
		
		/*
		for (int i = 0; i < n; i++) {
			Util.DoubleArrFill(((VariableNode)nodes.get(i)).state_factor,1/(double)num_label);					
		}
		
		
		for (int i = m; i < num_node; i++) {
			Node currentNode = nodes.get(i);
			for (int j = 0; j < currentNode.belief.size(); j++) {
				
				Util.DoubleArrFill(currentNode.belief.get(j), 1/(double)num_label);
			}
		}
		*/
		
		//set with prior
		
//		for (int i = m; i < num_node; i++) {
//			FactorNode fNode = (FactorNode) nodes.get(i);
//			
//			Integer[] neigbbors = fNode.neighbor_pos.keySet().toArray(new Integer[2]);
//			for (int j = 0; j < 2; j++) {
//				VariableNode vNode = (VariableNode) nodes.get(neigbbors[1-j]);
//				
//				int pos = fNode.neighbor_pos.get(neigbbors[j]);
//				for (int y = 0; y < num_label; y++) {
//					fNode.belief.get(pos)[y] = vNode.prior[y];
//				}
//				
//				
//			}
//		}
		
		
		for (int i = m; i < num_node; i++) {
			Node currentNode = nodes.get(i);
			for (int j = 0; j < currentNode.belief.size(); j++) {
				
				Util.DoubleArrFill(currentNode.belief.get(j), 1/(double)num_label);
			}
		}
		
		
		
		for (int i = 0; i < n; i++) {
			VariableNode vNode = (VariableNode) nodes.get(i);
			for (int j = 0; j < vNode.belief.size(); j++) {
				for (int y = 0; y < num_label; y++) {
					vNode.belief.get(j)[y] = vNode.prior[y];
				}
			}
		}
		
		
	}

	void SetVariableLabel(int u, int y) { ((VariableNode)nodes.get(u)).y = y; }
	void SetVariableStateFactor(int u, int y, double v){
		((VariableNode)nodes.get(u)).state_factor[y] = v;
	}
	
	void BeliefPropagation(int max_iter){
		int start, end, dir;
		
		converged = false;
		for (int iter = 0; iter < max_iter; iter++) {
			diff.diff_max = 0.0;
			
			if (iter%2 == 0) {
				start = num_node -1; end = -1;  dir = -1;
			}else {
				start = 0; end = num_node;  dir = 1;
			}
			
			for (int p = start ; p!=end; p += dir) {
				nodes.get(bfs_node[p]).BeliefPropagation(diff, this.labeled_given);
			}
			
			if (diff.diff_max < 1e-6) {
				break;
			}
			
			//print belief
//			 try {
//				FileWriter fw = new FileWriter("model/temp/belief.txt");
//				
//				 for (int i = 0; i < num_node; i++) {
//						Node node = nodes.get(i);
//						String beliefString = "";
//						for (int j = 0; j < node.belief.size(); j++) {
//							for (int j2 = 0; j2 < num_label; j2++) {
//								beliefString +=node.belief.get(j)[j2]+" ";
//							}
//							beliefString +=",";
//						}
//						
//						fw.write(beliefString+"\n");
//				}
//				 
//				 fw.flush();
//				 fw.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			 
//			System.exit(0);

		}
	}
	
	void CalculateMarginal(){
		
		// n variable nodes for y
		for (int i = 0; i < n; i++) {
			double sum_py = 0.0;
			
			//debug
//			String debugString = "debug-margin: ";
			
			VariableNode vNode = (VariableNode) nodes.get(i);
			for (int y = 0; y < num_label; y++) {
				
				vNode.marginal[y] = vNode.state_factor[y];
				
//				debugString +="State_factor: "+ vNode.marginal[y] ;
				
				for (int t = 0; t < vNode.belief.size(); t++) {
					vNode.marginal[y] *= vNode.belief.get(t)[y];
					
//					debugString +="\n *belief" + vNode.belief.get(t)[y]+"->"+vNode.marginal[y];
				}
//				debugString +="\n computed:"+ vNode.marginal[y] ;
				sum_py += vNode.marginal[y];
			}
			
			for (int y = 0; y <	num_label; y++) {
				vNode.marginal[y] /= sum_py;
//				if (Double.isNaN(vNode.marginal[y])) {
//					debugString +="\n"+"sum_py:"+sum_py;
//					System.err.println(debugString);
//					System.exit(0);
//				}
			}
		}
		
		//m factor nodes
		for (int i = n; i < num_node; i++) {
			
			double sump = 0.0;
			
			FactorNode fNode = (FactorNode) nodes.get(i);
			if (fNode.belief.size()==2) {
				for (int a = 0; a < num_label; a++) {
					for (int b = 0; b < num_label; b++) {
						fNode.marginal[a][b] += fNode.belief.get(0)[a] * 
								fNode.belief.get(1)[b]*
								fNode.func.GetValue(a, b);
						sump += fNode.marginal[a][b];
								
					}
				}
				
				for (int a = 0; a < num_label; a++) {
					for (int b = 0; b < num_label; b++) {
						fNode.marginal[a][b] /= sump;								
					}
				}
			}
			//need marginal3d
			if (fNode.belief.size()==3) {
				
			}
			//not for now, need marginal2d
			if (fNode.belief.size() > 3) {
				
			}
		}
	}

	void MaxSumPropagation(int max_iter){
		int start, end, dir;
		
		converged = false;
		for (int iter = 0; iter < max_iter; iter++) {
			diff.diff_max = 0.0;
			
			if (iter%2 == 0) {
				start = num_node -1; end = -1;  dir = -1;
			}else {
				start = 0; end = num_node;  dir = 1;
			}
			
			for (int p = start ; p!=end; p += dir) {
				nodes.get(bfs_node[p]).MaxSumPropagation(diff, this.labeled_given);
			}
			
			if (diff.diff_max < 1e-6) {
				break;
			}
		}
	}
	
	
}
