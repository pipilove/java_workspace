package pipi.fgm_prior;

public class DataSet {

	public int num_label_id;
	
	
}
