package pipi.dataclean;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class DataClean {
	
	
	private void net_bi_space(String basedir) {
		// TODO Auto-generated method stub
		String file_net = basedir + "network_reid.txt";
		String out_net = basedir + "network_reid_bi_space.txt";
		
		try {
			PrintWriter pw = new PrintWriter(out_net);
			
			Scanner scanner = new Scanner(new File(file_net));
			
			while (scanner.hasNextLine()) {
				String lineString = scanner.nextLine();
				String[] tpStrings = lineString.split(",");
				
				pw.println(tpStrings[0] + " "+tpStrings[1]);
			}
			
			scanner.close();
			pw.flush();
			pw.close();
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String basedir = "E:\\pipi\\";
		
		DataClean dataClean = new DataClean();
		
		dataClean.net_bi_space(basedir);
		
	}

}
