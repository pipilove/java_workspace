package FGM1_5;

import java.util.Map;
import java.util.TreeMap;

public class FactorFunction {
	
	
	double GetValue(int y1)  {return 0;}
	double GetValue(int y1, int y2) {return 0;}
	double GetValue(int y1, int y2, int y3) {return 0;}
	double GetValue(TreeMap<Integer, Integer> yMap) {return 0;}

}

class EdgeFactorFunction extends FactorFunction{
	
	int num_label;
	Map<Integer, Integer> feature_offset;
	double[] lambda;  //just a refer for space reduction
	int bias;
	
	public EdgeFactorFunction(int num_label, double[] lambda, Map<Integer, Integer> feature_offset, int bias) {
		// TODO Auto-generated constructor stub
		this.num_label = num_label;
		this.lambda = lambda;
		this.feature_offset = feature_offset;  //as 0 is the first
		this.bias = bias;
	}
	
	double GetValue(int y1) {
		return Math.exp(lambda[feature_offset.get(y1) +bias]);
	}
	
	double GetValue(int y1, int y2 ) {
		return Math.exp(lambda[feature_offset.get(y1 * num_label + y2) + bias]);
	} 
	
	double GetValue(int y1, int y2,int y3) {
		return Math.exp(lambda[feature_offset.get( y1 * num_label*num_label + y2*num_label + y3) + bias]);
	}
	
	double GetValue(int[] pos){
		int offset = bias;
		for (int i = 0; i < pos.length; i++) {
			offset += num_label*offset + pos[i];
		}
		
		return Math.exp(lambda[feature_offset.get(offset)]);
	}
	
	
}
