package FGM1_5;

public class DataSet {

	public int num_label_id;
	
	
}
